#!/usr/bin/python
# -*- coding: utf-8 -*-

from Plugins.Plugin import PluginDescriptor

def main(session, **kwargs):
    try:
        from Plugins.Extensions.DreamosatXEPG.plugin import DreamosatXSession
        session.open(DreamosatXSession)
    except:
        try:
            from plugin import DreamosatXSession
            session.open(DreamosatXSession)
        except Exception as e:
            from Screens.MessageBox import MessageBox
            session.open(MessageBox, "DreamosatX EPG Error: %s" % str(e), MessageBox.TYPE_ERROR)

def Plugins(**kwargs):
    return [PluginDescriptor(
        name="DreamosatX EPG",
        description="Modern EPG Plugin",
        where=PluginDescriptor.WHERE_EXTENSIONSMENU,
        fnc=main
    )]
