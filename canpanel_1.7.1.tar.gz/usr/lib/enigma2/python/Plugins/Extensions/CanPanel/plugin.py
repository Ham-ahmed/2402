from enigma import eTimer, getDesktop, gFont, eConsoleAppContainer, eLabel, ePixmap, gRGB, eListboxPythonMultiContent, eSlider
from enigma import RT_HALIGN_CENTER, RT_VALIGN_CENTER, RT_HALIGN_LEFT, RT_VALIGN_TOP, RT_WRAP
from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Screens.ChoiceBox import ChoiceBox
from Screens.VirtualKeyBoard import VirtualKeyBoard
from Components.ActionMap import ActionMap
from Components.Pixmap import Pixmap
from Components.Label import Label
from Components.Slider import Slider
from Screens.Console import Console
from Components.MenuList import MenuList
from Components.config import config, ConfigSubsection, ConfigSelection, ConfigText
from Components.MultiContent import MultiContentEntryPixmapAlphaTest, MultiContentEntryText
from Tools.LoadPixmap import LoadPixmap
from Tools.Directories import resolveFilename, SCOPE_PLUGINS
from twisted.web import client
from twisted.internet import defer
import os
import subprocess
import logging
import glob
import shutil
import urllib.request
import uuid

PLUGIN_VERSION = "1.7.1"
LOG_FILE = "/tmp/CanPanel_plugin.log"
FALLBACK_LOG_FILE = "/tmp/CanPanel_plugin_fallback.log"

def setup_logging():
    logger = logging.getLogger("CanPanel")
    logger.propagate = False
    if logger.handlers:
        logger.handlers.clear()
    logger.setLevel(logging.INFO)
    formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
    try:
        handler = logging.FileHandler(LOG_FILE, mode='a', encoding='utf-8')
        handler.setFormatter(formatter)
        logger.addHandler(handler)
    except Exception as e:
        try:
            fallback = logging.FileHandler(FALLBACK_LOG_FILE, mode='a', encoding='utf-8')
            fallback.setFormatter(formatter)
            logger.addHandler(fallback)
            logger.error(f"Primary log failed, using fallback: {str(e)}")
        except:
            pass
    stream = logging.StreamHandler()
    stream.setFormatter(formatter)
    logger.addHandler(stream)
    logger.info("CanPanel v1.7.1 logging initialized")
    return logger

logger = setup_logging()
VERSION_URL = "http://grbz.com.tr/apps/CANPANEL/cevrimici/version/171.txt"
UPDATE_COMMAND = "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/cevrimici/can_panel-1.0.sh -O - | /bin/sh"
INSTALLED_PLUGINS_FILE = "/usr/lib/enigma2/python/Plugins/Extensions/CanPanel/installed_plugins.txt"
BACKUP_PLUGINS_FILE = "/tmp/CanPanel_plugins_backup.txt"
PICTURES_DIR = "/usr/lib/enigma2/python/Plugins/Extensions/CanPanel/pictures/"
LANGUAGE_FILE = "/usr/lib/enigma2/python/Plugins/Extensions/CanPanel/selected_language.txt"
PICTURES_FILE_PATHS = [
    "/usr/lib/enigma2/python/Plugins/Extensions/CanPanel/pictures.txt",
    "/tmp/pictures.txt",
    "/usr/share/enigma2/pictures.txt"
]

config.plugins.CanPanel = ConfigSubsection()
language_choices = [("tr", "Türkçe - tr")]
config.plugins.CanPanel.language = ConfigSelection(default="tr", choices=language_choices)

CATEGORIES = [
    ("all", "Tüm Eklentiler", "/usr/lib/enigma2/python/Plugins/Extensions/CanPanel/icons/category_all.png"),
    ("iptv", "IPTV Panel", "/usr/lib/enigma2/python/Plugins/Extensions/CanPanel/icons/category_iptv.png"),
    ("softcam", "Softcam", "/usr/lib/enigma2/python/Plugins/Extensions/CanPanel/icons/category_softcam.png"),
    ("skin", "Skin/Arayüz", "/usr/lib/enigma2/python/Plugins/Extensions/CanPanel/icons/category_skin.png"),
    ("backup", "Backup/Yedekleme", "/usr/lib/enigma2/python/Plugins/Extensions/CanPanel/icons/category_backup.png"),
    ("utility", "Araçlar", "/usr/lib/enigma2/python/Plugins/Extensions/CanPanel/icons/category_utility.png"),
    ("bootlogo", "Bootlogo", "/usr/lib/enigma2/python/Plugins/Extensions/CanPanel/icons/category_bootlogo.png"),
    ("picon", "Picon", "/usr/lib/enigma2/python/Plugins/Extensions/CanPanel/icons/category_picon.png"),
    ("usta", "Forum Ustaları", "/usr/lib/enigma2/python/Plugins/Extensions/CanPanel/icons/category_ustalar.png"),
    ("system", "Sistem", "/usr/lib/enigma2/python/Plugins/Extensions/CanPanel/icons/category_system.png"),
    ("software", "sx88v2 Back-Up", "/usr/lib/enigma2/python/Plugins/Extensions/CanPanel/icons/cevrimici.png"),
]

PLUGIN_LIST = [
    ("Türkiye TV", "/usr/lib/enigma2/python/Plugins/Extensions/CanPanel/icons/turkıyetv.png", 
     "wget http://grbz.com.tr/apps/CANPANEL/home/uygulama/turkıyetv.sh -O - | /bin/sh",
     "wget http://grbz.com.tr/apps/CANPANEL/home/uygulama/turkıyetv_uninstall.sh -O - | /bin/sh",
     "Smlbird", "iptv", "enigma2-plugin-turkıyetv"),  
     
    ("Ezan Vakti", "/usr/lib/enigma2/python/Plugins/Extensions/CanPanel/icons/EzanVakti.png", 
     "wget http://grbz.com.tr/apps/CANPANEL/home/uygulama/EzanVakti.sh -O - | /bin/sh",
     "wget http://grbz.com.tr/apps/CANPANEL/home/uygulama/EzanVakti_uninstall.sh -O - | /bin/sh",
     "Smlbird", "utility", "enigma2-plugin-EzanVakti"),  
     
    ("Türkçe Radyo", "/usr/lib/enigma2/python/Plugins/Extensions/CanPanel/icons/TRRadio.png", 
     "wget http://grbz.com.tr/apps/CANPANEL/home/uygulama/TRRadio.sh -O - | /bin/sh",
     "wget http://grbz.com.tr/apps/CANPANEL/home/uygulama/TRRadio_uninstall.sh -O - | /bin/sh",
     "Musa0124", "iptv", "enigma2-plugin-TRRadio"),  
          
    ("YouTube_h1", "/usr/lib/enigma2/python/Plugins/Extensions/CanPanel/icons/YouTube_HD.png", 
     "wget http://grbz.com.tr/apps/CANPANEL/home/uygulama/youtube_h1.sh -O - | /bin/sh",
     "wget http://grbz.com.tr/apps/CANPANEL/home/uygulama/youtube_h1_uninstall.sh -O - | /bin/sh",
     "YouTube_h1", "utility", "enigma2-plugin-YouTube"),   
     
     ("YouTube_Py3", "/usr/lib/enigma2/python/Plugins/Extensions/CanPanel/icons/YouTube_HD.png", 
     "wget http://grbz.com.tr/apps/CANPANEL/home/uygulama/youtube_py3.sh -O - | /bin/sh",
     "wget http://grbz.com.tr/apps/CANPANEL/home/uygulama/youtube_py3_uninstall.sh -O - | /bin/sh",
     "YouTube_Py3", "utility", "enigma2-plugin-YouTube"),  
     
     ("CI+Helper", "/usr/lib/enigma2/python/Plugins/Extensions/CanPanel/icons/CI+ Helper.png", 
     "wget http://grbz.com.tr/apps/CANPANEL/home/uygulama/CI+Helper.sh -O - | /bin/sh",
     "wget http://grbz.com.tr/apps/CANPANEL/home/uygulama/CI+Helper.sh_uninstall.sh -O - | /bin/sh",
     "CI+Helper", "utility", "enigma2-plugin-CI+Helper"),
     
    ("AISubtitleHybrid", "/usr/lib/enigma2/python/Plugins/Extensions/CanPanel/icons/AISubtitleHybrid.png", 
     "wget http://grbz.com.tr/apps/CANPANEL/home/uygulama/AISubtitleHybrid.sh -O - | /bin/sh",
     "wget http://grbz.com.tr/apps/CANPANEL/home/uygulama/AISubtitleHybrid_uninstall.sh -O - | /bin/sh",
     "AISubtitleHybrid", "utility", "enigma2-plugin-aisubtitles"),
     
    ("AISubtitles-2.2", "/usr/lib/enigma2/python/Plugins/Extensions/CanPanel/icons/Subtitles.png", 
     "wget http://grbz.com.tr/apps/CANPANEL/home/uygulama/AISubtitles_2.2.sh -O - | /bin/sh",
     "wget http://grbz.com.tr/apps/CANPANEL/home/uygulama/AISubtitles_uninstall.sh -O - | /bin/sh",
     "AISubtitles-2.0", "utility", "enigma2-plugin-aisubtitles"),

    ("AISubtitles-2.0", "/usr/lib/enigma2/python/Plugins/Extensions/CanPanel/icons/Subtitles.png", 
     "wget http://grbz.com.tr/apps/CANPANEL/home/uygulama/AISubtitles_2.0.sh -O - | /bin/sh",
     "wget http://grbz.com.tr/apps/CANPANEL/home/uygulama/AISubtitles_uninstall.sh -O - | /bin/sh",
     "AISubtitles-2.0", "utility", "enigma2-plugin-aisubtitles"),
    
    ("AISubtitles-1.8", "/usr/lib/enigma2/python/Plugins/Extensions/CanPanel/icons/Subtitles.png", 
     "wget http://grbz.com.tr/apps/CANPANEL/home/uygulama/AISubtitles-1.8.sh -O - | /bin/sh",
     "wget http://grbz.com.tr/apps/CANPANEL/home/uygulama/AISubtitles-1.8_uninstall.sh -O - | /bin/sh",
     "AISubtitles-1.8", "utility", "aisubtitles-1.8"),
    
    ("AISubtitles-key", "/usr/lib/enigma2/python/Plugins/Extensions/CanPanel/icons/Subtitles.png", 
     "wget http://grbz.com.tr/apps/CANPANEL/home/uygulama/AISubtitles-key.sh -O - | /bin/sh",
     "wget http://grbz.com.tr/apps/CANPANEL/home/uygulama/AISubtitles-key_uninstall.sh -O - | /bin/sh",
     "AISubtitles-key", "utility", "aisubtitles-key"),
    
    ("AJPanel Turkce", "/usr/lib/enigma2/python/Plugins/Extensions/CanPanel/icons/ajturkce.png", 
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/home/uygulama/Ajpanel_Turkce.sh -O - | /bin/sh",
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/home/uygulama/Ajpanel_Turkce_uninstall.sh -O - | /bin/sh",
     "AJPanel Turkce", "iptv", "ajpanel-turkce"),
    
    ("AJPanel", "/usr/lib/enigma2/python/Plugins/Extensions/CanPanel/icons/AJPanel.png", 
     "wget -q --no-check-certificate https://raw.githubusercontent.com/AMAJamry/AJPanel/main/installer.sh -O - | /bin/sh",
     "wget -q --no-check-certificate https://raw.githubusercontent.com/AMAJamry/AJPanel/main/uninstall.sh -O - | /bin/sh",
     "AJPanel", "iptv", "ajpanel"),
    
    ("AJPanel Ozel Menu", "/usr/lib/enigma2/python/Plugins/Extensions/CanPanel/icons/CanPanel.png", 
     "wget http://grbz.com.tr/apps/CANPANEL/home/CanPanel/Ajpanel_Dostpanel-3.0.sh -O - | /bin/sh",
     "wget http://grbz.com.tr/apps/CANPANEL/home/CanPanel/Ajpanel_Dostpanel-3.0_uninstall.sh -O - | /bin/sh",
     "AJPanel Ozel Menu", "iptv", "ajpanel-ozel-menu"),
    
    ("MultistalkerPro1.2", "/usr/lib/enigma2/python/Plugins/Extensions/CanPanel/icons/multistalker.png", 
     "wget -q --no-check-certificate https://raw.githubusercontent.com/biko-73/Multi-Stalker/main/pro/installer.sh -O - | /bin/sh",
     "wget -q --no-check-certificate https://raw.githubusercontent.com/biko-73/Multi-Stalker/main/pro/uninstall.sh -O - | /bin/sh",
     "MultistalkerPro1.2", "iptv", "multistalker-pro"),
    
    ("Bouquetmaker", "/usr/lib/enigma2/python/Plugins/Extensions/CanPanel/icons/Bouquetmaker.png", 
     "wget -q --no-check-certificate https://raw.githubusercontent.com/biko-73/BouquetMakerXtream/main/installer.sh -O - | /bin/sh",
     "wget -q --no-check-certificate https://raw.githubusercontent.com/biko-73/BouquetMakerXtream/main/uninstall.sh -O - | /bin/sh",
     "Bouquetmaker", "utility", "bouquetmaker-xtream"),
    
    ("eStalker", "/usr/lib/enigma2/python/Plugins/Extensions/CanPanel/icons/eStalker.png", 
     "wget -q --no-check-certificate https://raw.githubusercontent.com/biko-73/Estalker/main/installer.sh -O - | /bin/sh",
     "wget -q --no-check-certificate https://raw.githubusercontent.com/biko-73/Estalker/main/uninstall.sh -O - | /bin/sh",
     "eStalker", "iptv", "estalker"),
    
    ("eStalker Web", "/usr/lib/enigma2/python/Plugins/Extensions/CanPanel/icons/eStalkerweb.png", 
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/home/uygulama/eStalkerWeb.sh -O - | /bin/sh",
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/home/uygulama/eStalkerWeb_uninstall.sh -O - | /bin/sh",
     "eStalker Web", "iptv", "estalker-web"),
    
    ("Xstreamity", "/usr/lib/enigma2/python/Plugins/Extensions/CanPanel/icons/Xstreamity.png", 
     "wget -q --no-check-certificate https://raw.githubusercontent.com/biko-73/xstreamity/main/installer.sh -O - | /bin/sh",
     "wget -q --no-check-certificate https://raw.githubusercontent.com/biko-73/xstreamity/main/uninstall.sh -O - | /bin/sh",
     "Xstreamity", "iptv", "xstreamity"),
    
    ("Xklass", "/usr/lib/enigma2/python/Plugins/Extensions/CanPanel/icons/Xklass.png", 
     "wget -q --no-check-certificate https://raw.githubusercontent.com/biko-73/xklass/main/installer.sh -O - | /bin/sh",
     "wget -q --no-check-certificate https://raw.githubusercontent.com/biko-73/xklass/main/uninstall.sh -O - | /bin/sh",
     "Xklass", "iptv", "xklass"),
    
    ("Weatherplugin-2.X", "/usr/lib/enigma2/python/Plugins/Extensions/CanPanel/icons/Weatherplugin.png", 
     "wget -q --no-check-certificate https://gitlab.com/eliesat/extensions/-/raw/main/weatherplugin/weatherplugin.sh -O - | /bin/sh",
     "wget -q --no-check-certificate https://gitlab.com/eliesat/extensions/-/raw/main/weatherplugin/weatherplugin-uninstall.sh -O - | /bin/sh",
     "Weatherplugin-2.X", "utility", "weatherplugin"),
    
    ("Weather MSN", "/usr/lib/enigma2/python/Plugins/Extensions/CanPanel/icons/WeatherMSN.png", 
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/home/uygulama/weather_msn.sh -O - | /bin/sh",
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/home/uygulama/weather_msn_uninstall.sh -O - | /bin/sh",
     "Weather MSN", "utility", "weather-msn"),
    
    ("SpeedTest 1.8", "/usr/lib/enigma2/python/Plugins/Extensions/CanPanel/icons/SpeedTest.png", 
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/home/uygulama/InternetSpeedTest.sh -O - | /bin/sh",
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/home/uygulama/InternetSpeedTest_uninstall.sh -O - | /bin/sh",
     "SpeedTest 1.8", "utility", "speedtest"),
    
    ("IPAudio 8.xx", "/usr/lib/enigma2/python/Plugins/Extensions/CanPanel/icons/IPAudio.png", 
     "wget -q --no-check-certificate https://raw.githubusercontent.com/popking159/ipaudio/main/installer-ipaudio.sh -O - | /bin/sh",
     "wget -q --no-check-certificate https://raw.githubusercontent.com/popking159/ipaudio/main/uninstall-ipaudio.sh -O - | /bin/sh",
     "IPAudio 8.xx", "iptv", "ipaudio"),
    
    ("IPAudio_Ses", "/usr/lib/enigma2/python/Plugins/Extensions/CanPanel/icons/IPAudio.png", 
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/home/uygulama/hosts_IPAudio.sh -O - | /bin/sh",
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/home/uygulama/hosts_IPAudio_uninstall.sh -O - | /bin/sh",
     "IPAudio_Ses", "iptv", "ipaudio-ses"),
    
    ("FootOnsat", "/usr/lib/enigma2/python/Plugins/Extensions/CanPanel/icons/FootOnsat.png", 
     "wget -q --no-check-certificate https://raw.githubusercontent.com/fairbird/FootOnsat/main/Download/install.sh -O - | /bin/sh",
     "wget -q --no-check-certificate https://raw.githubusercontent.com/fairbird/FootOnsat/main/Download/uninstall.sh -O - | /bin/sh",
     "FootOnsat", "utility", "footonsat"),
    
    ("KeyAdder", "/usr/lib/enigma2/python/Plugins/Extensions/CanPanel/icons/KeyAdder.png", 
     "wget -q --no-check-certificate https://raw.githubusercontent.com/fairbird/KeyAdder/main/installer.sh -O - | /bin/sh",
     "wget -q --no-check-certificate https://raw.githubusercontent.com/fairbird/KeyAdder/main/uninstall.sh -O - | /bin/sh",
     "KeyAdder", "utility", "keyadder"),
    
    ("DCWKeyAdd", "/usr/lib/enigma2/python/Plugins/Extensions/CanPanel/icons/DCWKeyAdd.png", 
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/home/uygulama/DCWKeyAdd.sh -O - | /bin/sh",
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/home/uygulama/DCWKeyAdd_uninstall.sh -O - | /bin/sh",
     "DCWKeyAdd", "utility", "dcwkeyadd"),
    
    ("Iptosat", "/usr/lib/enigma2/python/Plugins/Extensions/CanPanel/icons/Iptosat.png", 
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/home/uygulama/iptosat-1.8.sh -O - | /bin/sh",
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/home/uygulama/iptosat-1.8_uninstall.sh -O - | /bin/sh",
     "Iptosat", "iptv", "iptosat"),
    
    ("automatic-full-backup", "/usr/lib/enigma2/python/Plugins/Extensions/CanPanel/icons/FullBackup.png", 
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/home/uygulama/FullBackup.sh -O - | /bin/sh",
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/home/uygulama/FullBackup_uninstall.sh -O - | /bin/sh",
     "automatic-full-backup", "backup", "full-backup"),
    
    ("VpnManager", "/usr/lib/enigma2/python/Plugins/Extensions/CanPanel/icons/VpnManager.png", 
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/home/uygulama/vpnmanager.sh -O - | /bin/sh",
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/home/uygulama/vpnmanager_uninstall.sh -O - | /bin/sh",
     "VpnManager", "utility", "vpnmanager"),
    
    ("Ultracam", "/usr/lib/enigma2/python/Plugins/Extensions/CanPanel/icons/oscam.png", 
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/home/oscam/ultracam.sh -O - | /bin/sh",
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/home/oscam/ultracam-uninstall.sh -O - | /bin/sh",
     "MOHAMED_OS", "softcam", "ultracam"),
    
    ("supcam", "/usr/lib/enigma2/python/Plugins/Extensions/CanPanel/icons/oscam.png", 
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/home/oscam/supcam.sh -O - | /bin/sh",
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/home/oscam/supcam-uninstall.sh -O - | /bin/sh",
     "MOHAMED_OS", "softcam", "supcam"),
    
    ("powercam", "/usr/lib/enigma2/python/Plugins/Extensions/CanPanel/icons/oscam.png", 
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/home/oscam/powercam.sh -O - | /bin/sh",
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/home/oscam/powercam-uninstall.sh -O - | /bin/sh",
     "MOHAMED_OS", "softcam", "powercam"),
    
    ("gosatplus", "/usr/lib/enigma2/python/Plugins/Extensions/CanPanel/icons/oscam.png", 
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/home/oscam/gosatplus.sh -O - | /bin/sh",
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/home/oscam/gosatplus-uninstall.sh -O - | /bin/sh",
     "MOHAMED_OS", "softcam", "gosatplus"),
     
     ("Oscam_M_OS", "/usr/lib/enigma2/python/Plugins/Extensions/CanPanel/icons/oscam.png", 
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/home/oscam/oscam.sh -O - | /bin/sh",
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/home/oscam/oscam-uninstall.sh -O - | /bin/sh",
     "MOHAMED_OS", "softcam", "oscam-m-os"),
       
    ("OScam_audi06_19", "/usr/lib/enigma2/python/Plugins/Extensions/CanPanel/icons/oscam.png", 
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/home/oscam/audi06_19_oscam_ipk.sh -O - | /bin/sh",
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/home/oscam/audi06_19_oscam_ipk-uninstall.sh -O - | /bin/sh",
     "audi06_19", "usta", "OScam_ipk audi06_19"),    
 
     ("OScam_audi06_19", "/usr/lib/enigma2/python/Plugins/Extensions/CanPanel/icons/oscam.png", 
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/home/oscam/audi06_19_oscam_ipk.sh -O - | /bin/sh",
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/home/oscam/audi06_19_oscam_ipk-uninstall.sh -O - | /bin/sh",
     "audi06_19", "softcam", "OScam_ipk audi06_19"), 
     
    ("OScam Lewi45", "/usr/lib/enigma2/python/Plugins/Extensions/CanPanel/icons/oscam.png", 
     "wget -q --no-check-certificate https://raw.githubusercontent.com/levi-45/Levi45Emulator/main/installer.sh -O - | /bin/sh",
     "wget -q --no-check-certificate https://raw.githubusercontent.com/levi-45/Levi45Emulator/main/uninstall.sh -O - | /bin/sh",
     "Lewi45", "softcam", "oscam-lewi45"),    
         
    ("Ncam", "/usr/lib/enigma2/python/Plugins/Extensions/CanPanel/icons/ncam.png", 
     "wget -q --no-check-certificate https://raw.githubusercontent.com/biko-73/Ncam_EMU/main/installer.sh -O - | /bin/sh",
     "wget -q --no-check-certificate https://raw.githubusercontent.com/biko-73/Ncam_EMU/main/uninstall.sh -O - | /bin/sh",
     "fairbird", "softcam", "ncam"),
     
     ("SoftCam Config", "/usr/lib/enigma2/python/Plugins/Extensions/CanPanel/icons/oscam.png", 
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/cevrimici/key/SoftCam_conf.sh -O - | /bin/sh",
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/cevrimici/key/SoftCam_conf-uninstall.sh -O - | /bin/sh",
     "SoftCam Config", "softcam", "SoftCam Config"),
     
     ("Oscam_kite888_icam", "/usr/lib/enigma2/python/Plugins/Extensions/CanPanel/icons/oscam.png", 
     "wget -q --no-check-certificate https://raw.githubusercontent.com/biko-73/OSCamicam_Kitte888/main/installer.sh -O - | /bin/sh",
     "wget -q --no-check-certificate https://raw.githubusercontent.com/biko-73/OSCamicam_Kitte888/main/uninstall.sh -O - | /bin/sh",
     "kite888", "softcam", "Oscam_kite888_icam"),
    
    ("METRIX-FHD", "/usr/lib/enigma2/python/Plugins/Extensions/CanPanel/icons/METRIX-FHD.png", 
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/home/arayuz/Metrixfhd-neo.sh -O - | /bin/sh",
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/home/arayuz/Metrixfhd-neo_uninstall.sh -O - | /bin/sh",
     "METRIX-FHD", "skin", "metrix-fhd"),
    
    ("Malek-FHD", "/usr/lib/enigma2/python/Plugins/Extensions/CanPanel/icons/Malek-FHD.png", 
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/home/arayuz/Malek-FHD-2.0.sh -O - | /bin/sh",
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/home/arayuz/Malek-FHD-2.0_uninstall.sh -O - | /bin/sh",
     "Malek-FHD", "skin", "malek-fhd"),
    
    ("Fury-FHD", "/usr/lib/enigma2/python/Plugins/Extensions/CanPanel/icons/Fury-FHD.png", 
     "wget -q --no-check-certificate https://raw.githubusercontent.com/islam-2412/IPKS/refs/heads/main/fury/installer.sh -O - | /bin/sh",
     "wget -q --no-check-certificate https://raw.githubusercontent.com/islam-2412/IPKS/refs/heads/main/fury/uninstall.sh -O - | /bin/sh",
     "Fury-FHD", "skin", "fury-fhd"),
    
    ("Aglare-fhd", "/usr/lib/enigma2/python/Plugins/Extensions/CanPanel/icons/Aglare-fhd.png", 
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/home/arayuz/aglare-5.7.sh -O - | /bin/sh",
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/home/arayuz/aglare-5.7_uninstall.sh -O - | /bin/sh",
     "Aglare-fhd", "skin", "aglare-fhd"),
    
    ("Aglare-fhd-pli", "/usr/lib/enigma2/python/Plugins/Extensions/CanPanel/icons/Aglare-fhd.png", 
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/home/arayuz/aglare-pli-5.2.sh -O - | /bin/sh",
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/home/arayuz/aglare-pli-5.2_uninstall.sh -O - | /bin/sh",
     "OpenPLI", "skin", "aglare-fhd-pli"),
    
    ("Maxy-fhd-1.4 Atv7.6", "/usr/lib/enigma2/python/Plugins/Extensions/CanPanel/icons/Maxy-fhd-1.3.png", 
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/home/arayuz/Maxy-fhd-1.4.sh -O - | /bin/sh",
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/home/arayuz/Maxy-fhd-1.4-uninstall.sh -O - | /bin/sh",
     "OpenATV 7.6", "skin", "maxy-fhd"),
    
    ("Maxy-fhd-1.3", "/usr/lib/enigma2/python/Plugins/Extensions/CanPanel/icons/Maxy-fhd-1.3.png", 
     "wget -q --no-check-certificate https://gitlab.com/eliesat/skins/-/raw/main/all/maxy-fhd/maxy-fhd.sh -O - | /bin/sh",
     "wget -q --no-check-certificate https://gitlab.com/eliesat/skins/-/raw/main/all/maxy-fhd/maxy-fhd-uninstall.sh -O - | /bin/sh",
     "OpenATV", "skin", "maxy-fhd"),
    
    ("Maxi-fhd-pli-1.0", "/usr/lib/enigma2/python/Plugins/Extensions/CanPanel/icons/Maxy-fhd-1.3.png", 
     "wget -q --no-check-certificate https://gitlab.com/eliesat/skins/-/raw/main/all/maxy-fhd/maxy-fhd-pli.sh -O - | /bin/sh",
     "wget -q --no-check-certificate https://gitlab.com/eliesat/skins/-/raw/main/all/maxy-fhd/maxy-fhd-pli-uninstall.sh -O - | /bin/sh",
     "OpenPLI", "skin", "maxi-fhd-pli"),
    
    ("Ozeta-fhd-pli", "/usr/lib/enigma2/python/Plugins/Extensions/CanPanel/icons/Ozeta-fhd.png", 
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/home/arayuz/ozeta-fhd-1.0.sh -O - | /bin/sh",
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/home/arayuz/ozeta-fhd-1.0_uninstall.sh -O - | /bin/sh",
     "OpenPLI", "skin", "ozeta-fhd-pli"),
    
    ("Ozeta-fhd", "/usr/lib/enigma2/python/Plugins/Extensions/CanPanel/icons/Ozeta-fhd.png", 
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/home/arayuz/ozeta-2.0.sh -O - | /bin/sh",
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/home/arayuz/ozeta-2.0_uninstall.sh -O - | /bin/sh",
     "Ozeta-fhd", "skin", "ozeta-fhd"),
     
     ("BS ENIGMA2LOGO PAKET", "/usr/lib/enigma2/python/Plugins/Extensions/CanPanel/icons/BS_logopaketi.png", 
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/home/bootlogo/BS_logopaketi.sh -O - | /bin/sh",
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/home/bootlogo/BS_logopaketi_uninstall.sh -O - | /bin/sh",
     "biperva", "bootlogo", "bootlogo-ts"),
     
     
     ("BS ENIGMA2LOGO PAKET", "/usr/lib/enigma2/python/Plugins/Extensions/CanPanel/icons/BS_logopaketi.png", 
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/home/bootlogo/BS_logopaketi.sh -O - | /bin/sh",
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/home/bootlogo/BS_logopaketi_uninstall.sh -O - | /bin/sh",
     "biperva", "usta", "bootlogo-ts"),
     
     
     ("TS ENIGMA2LOGO PAKET", "/usr/lib/enigma2/python/Plugins/Extensions/CanPanel/icons/tslogo.jpg", 
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/home/bootlogo/TS_logopaketi.sh -O - | /bin/sh",
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/home/bootlogo/TS_logopaketi_uninstall.sh -O - | /bin/sh",
     "biperva", "bootlogo", "bootlogo-bjk"),
     
     ("BJK ENIGMA2LOGO PAKET", "/usr/lib/enigma2/python/Plugins/Extensions/CanPanel/icons/bjklogo.jpg", 
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/home/bootlogo/BJK_logopaketi.sh -O - | /bin/sh",
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/home/bootlogo/BJK_logopaketi_uninstall.sh -O - | /bin/sh",
     "biperva", "bootlogo", "bootlogo-bjk"),
    
    ("GS ENIGMA2LOGO PAKET", "/usr/lib/enigma2/python/Plugins/Extensions/CanPanel/icons/gslogo.jpg", 
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/home/bootlogo/GS_logopaketi.sh -O - | /bin/sh",
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/home/bootlogo/GS_logopaketi_uninstall.sh -O - | /bin/sh",
     "biperva", "bootlogo", "bootlogo-gs"),
    
    ("FB ENIGMA2LOGO PAKET", "/usr/lib/enigma2/python/Plugins/Extensions/CanPanel/icons/fblogo.jpg", 
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/home/bootlogo/FB_logopaketi.sh -O - | /bin/sh",
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/home/bootlogo/FB_logopaketi_uninstall.sh -O - | /bin/sh",
     "biperva", "bootlogo", "bootlogo-fb"),   
     
     ("TS ENIGMA2LOGO PAKET", "/usr/lib/enigma2/python/Plugins/Extensions/CanPanel/icons/tslogo.jpg", 
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/home/bootlogo/TS_logopaketi.sh -O - | /bin/sh",
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/home/bootlogo/TS_logopaketi_uninstall.sh -O - | /bin/sh",
     "biperva", "usta", "bootlogo-bjk"),
     
     ("BJK ENIGMA2LOGO PAKET", "/usr/lib/enigma2/python/Plugins/Extensions/CanPanel/icons/bjklogo.jpg", 
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/home/bootlogo/BJK_logopaketi.sh -O - | /bin/sh",
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/home/bootlogo/BJK_logopaketi_uninstall.sh -O - | /bin/sh",
     "biperva", "usta", "bootlogo-bjk"),
    
    ("GS ENIGMA2LOGO PAKET", "/usr/lib/enigma2/python/Plugins/Extensions/CanPanel/icons/gslogo.jpg", 
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/home/bootlogo/GS_logopaketi.sh -O - | /bin/sh",
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/home/bootlogo/GS_logopaketi_uninstall.sh -O - | /bin/sh",
     "biperva", "usta", "bootlogo-gs"),
    
    ("FB ENIGMA2LOGO PAKET", "/usr/lib/enigma2/python/Plugins/Extensions/CanPanel/icons/fblogo.jpg", 
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/home/bootlogo/FB_logopaketi.sh -O - | /bin/sh",
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/home/bootlogo/FB_logopaketi_uninstall.sh -O - | /bin/sh",
     "biperva", "usta", "bootlogo-fb"),  
    
    ("GTEPE ENIGMA2LOGO PAKET", "/usr/lib/enigma2/python/Plugins/Extensions/CanPanel/icons/gztepelogo.png", 
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/home/bootlogo/GTEPE_logopaketi.sh -O - | /bin/sh",
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/home/bootlogo/GTEPE_logopaketi_uninstall.sh -O - | /bin/sh",
     "biperva", "bootlogo", "bootlogo-gtp"),    
    
    ("GTEPE ENIGMA2LOGO PAKET", "/usr/lib/enigma2/python/Plugins/Extensions/CanPanel/icons/gztepelogo.png", 
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/home/bootlogo/GTEPE_logopaketi.sh -O - | /bin/sh",
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/home/bootlogo/GTEPE_logopaketi_uninstall.sh -O - | /bin/sh",
     "biperva", "usta", "bootlogo-gtp"),   
      
     
    ("BOOTLOGO GOZTEPE", "/usr/lib/enigma2/python/Plugins/Extensions/CanPanel/icons/gztepelogo.png", 
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/home/bootlogo/logogtepe.sh -O - | /bin/sh",
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/home/bootlogo/logogtepe_uninstall.sh -O - | /bin/sh",
     "Musa0124", "bootlogo", "bootlogo-bjk"),  
     
    ("BOOTLOGO BJK", "/usr/lib/enigma2/python/Plugins/Extensions/CanPanel/icons/bjklogo.jpg", 
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/home/bootlogo/logo6.sh -O - | /bin/sh",
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/home/bootlogo/logo6_uninstall.sh -O - | /bin/sh",
     "Musa0124", "bootlogo", "bootlogo-bjk"),
    
    ("BOOTLOGO GS", "/usr/lib/enigma2/python/Plugins/Extensions/CanPanel/icons/gslogo.jpg", 
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/home/bootlogo/logo7.sh -O - | /bin/sh",
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/home/bootlogo/logo7_uninstall.sh -O - | /bin/sh",
     "Musa0124", "bootlogo", "bootlogo-gs"),
    
    ("BOOTLOGO FB", "/usr/lib/enigma2/python/Plugins/Extensions/CanPanel/icons/fblogo.jpg", 
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/home/bootlogo/logo8.sh -O - | /bin/sh",
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/home/bootlogo/logo8_uninstall.sh -O - | /bin/sh",
     "Musa0124", "bootlogo", "bootlogo-fb"),
    
    ("BOOTLOGO TS", "/usr/lib/enigma2/python/Plugins/Extensions/CanPanel/icons/tslogo.jpg", 
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/home/bootlogo/logo9.sh -O - | /bin/sh",
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/home/bootlogo/logo9_uninstall.sh -O - | /bin/sh",
     "Musa0124", "bootlogo", "bootlogo-ts"),
    
    ("ACILIS LOGO 1", "/usr/lib/enigma2/python/Plugins/Extensions/CanPanel/icons/logo1.png", 
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/home/bootlogo/logo1.sh -O - | /bin/sh",
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/home/bootlogo/logo1_uninstall.sh -O - | /bin/sh",
     "Musa0124", "bootlogo", "bootlogo-1"),
    
    ("ACILIS LOGO 2", "/usr/lib/enigma2/python/Plugins/Extensions/CanPanel/icons/logo2.png", 
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/home/bootlogo/logo2.sh -O - | /bin/sh",
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/home/bootlogo/logo2_uninstall.sh -O - | /bin/sh",
     "Musa0124", "bootlogo", "bootlogo-2"),
    
    ("ACILIS LOGO 3", "/usr/lib/enigma2/python/Plugins/Extensions/CanPanel/icons/logo3.png", 
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/home/bootlogo/logo3.sh -O - | /bin/sh",
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/home/bootlogo/logo3_uninstall.sh -O - | /bin/sh",
     "Musa0124", "bootlogo", "bootlogo-3"),
    
    ("PARROT LOGO", "/usr/lib/enigma2/python/Plugins/Extensions/CanPanel/icons/parrot.png", 
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/home/bootlogo/logo4.sh -O - | /bin/sh",
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/home/bootlogo/logo4_uninstall.sh -O - | /bin/sh",
     "PARROT LOGO", "bootlogo", "bootlogo-parrot"),
    
    ("OCTAGON LOGO", "/usr/lib/enigma2/python/Plugins/Extensions/CanPanel/icons/octagon.png", 
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/home/bootlogo/logo5.sh -O - | /bin/sh",
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/home/bootlogo/logo5_uninstall.sh -O - | /bin/sh",
     "OCTAGON LOGO", "bootlogo", "bootlogo-octagon"),
    
    ("Swapper Manzara", "/usr/lib/enigma2/python/Plugins/Extensions/CanPanel/icons/bootlogos.png", 
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/home/bootlogo/dost_botlogo1.0.sh -O - | /bin/sh",
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/home/bootlogo/dost_botlogo1.0_uninstall.sh -O - | /bin/sh",
     "Musa0124", "bootlogo", "bootlogo-swapper"),
    
    ("Kanal Listesi", "/usr/lib/enigma2/python/Plugins/Extensions/CanPanel/icons/settings.png", 
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/home/araclar/kanal_backup.sh -O - | /bin/sh",
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/home/araclar/kanal_backup_uninstall.sh -O - | /bin/sh",
     "Kanal Listesi", "backup", "kanal-listesi"),
    
    ("Motorlu Kanal Listesi", "/usr/lib/enigma2/python/Plugins/Extensions/CanPanel/icons/settings.png", 
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/home/araclar/kanal_backup_motor.sh -O - | /bin/sh",
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/home/araclar/kanal_backup_motor_uninstall.sh -O - | /bin/sh",
     "chveneburi", "backup", "motorlu-kanal-listesi"),
    
    ("Motorlu Kanal Listesi", "/usr/lib/enigma2/python/Plugins/Extensions/CanPanel/icons/settings.png", 
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/home/araclar/kanal_backup_motor.sh -O - | /bin/sh",
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/home/araclar/kanal_backup_motor_uninstall.sh -O - | /bin/sh",
     "chveneburi", "usta", "motorlu-kanal-listesi"),
    
    ("Güncel TP listesi(satellites) chveneburi", "/usr/lib/enigma2/python/Plugins/Extensions/CanPanel/icons/settings.png", 
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/home/araclar/chveneburi_satellites.sh -O - | /bin/sh",
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/home/araclar/chveneburi_satellites_uninstall.sh -O - | /bin/sh",
     "chveneburi", "backup", "motorlu-kanal-listesi"),
    
    ("Güncel TP listesi(satellites) chveneburi", "/usr/lib/enigma2/python/Plugins/Extensions/CanPanel/icons/settings.png", 
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/home/araclar/chveneburi_satellites.sh -O - | /bin/sh",
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/home/araclar/chveneburi_satellites_uninstall.sh -O - | /bin/sh",
     "chveneburi", "usta", "motorlu-kanal-listesi"),
    
    ("12 Uydulu Kanal Listesi", "/usr/lib/enigma2/python/Plugins/Extensions/CanPanel/icons/settings.png", 
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/home/araclar/kanal_backup_salim1965.sh -O - | /bin/sh",
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/home/araclar/kanal_backup_salim1965_uninstall.sh -O - | /bin/sh",
     "salim1965", "backup", "12uydulu-kanal-listesi"),
    
    ("12 Uydulu Kanal Listesi", "/usr/lib/enigma2/python/Plugins/Extensions/CanPanel/icons/settings.png", 
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/home/araclar/kanal_backup_salim1965.sh -O - | /bin/sh",
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/home/araclar/kanal_backup_salim1965_uninstall.sh -O - | /bin/sh",
     "salim1965", "usta", "12uydulu-kanal-listesi"),
    
    ("Güncel TP listesi(satellites)  salim1965", "/usr/lib/enigma2/python/Plugins/Extensions/CanPanel/icons/settings.png", 
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/home/araclar/salim1965_satellites.sh -O - | /bin/sh",
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/home/araclar/salim1965_satellites.sh_uninstall.sh -O - | /bin/sh",
     "salim1965", "usta", "12uydulu-kanal-listesi"),
    
    ("Güncel TP listesi(satellites)  salim1965", "/usr/lib/enigma2/python/Plugins/Extensions/CanPanel/icons/settings.png", 
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/home/araclar/salim1965_satellites.sh -O - | /bin/sh",
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/home/araclar/salim1965_satellites.sh_uninstall.sh -O - | /bin/sh",
     "salim1965", "backup", "12uydulu-kanal-listesi"),
     
    ("42E Picon", "/usr/lib/enigma2/python/Plugins/Extensions/CanPanel/icons/settings.png", 
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/home/picon/piconturksat.sh -O - | /bin/sh",
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/home/picon/piconturksat_uninstall.sh -O - | /bin/sh",
     "42E Picon", "picon", "picon-42e"),
    
    ("16E Picon", "/usr/lib/enigma2/python/Plugins/Extensions/CanPanel/icons/settings.png", 
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/home/picon/piconeutelsat16.sh -O - | /bin/sh",
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/home/picon/piconeutelsat16_uninstall.sh -O - | /bin/sh",
     "16E Picon", "picon", "picon-16e"),
    
    ("13E Picon", "/usr/lib/enigma2/python/Plugins/Extensions/CanPanel/icons/settings.png", 
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/home/picon/piconhotbird13.sh -O - | /bin/sh",
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/home/picon/piconhotbird13_uninstall.sh -O - | /bin/sh",
     "13E Picon", "picon", "picon-13e"),
    
    ("19.2E Picon", "/usr/lib/enigma2/python/Plugins/Extensions/CanPanel/icons/settings.png", 
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/home/picon/piconastra19.sh -O - | /bin/sh",
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/home/picon/piconastra19_uninstall.sh -O - | /bin/sh",
     "19.2E Picon", "picon", "picon-19.2e"),
    
    ("23.5E Picon", "/usr/lib/enigma2/python/Plugins/Extensions/CanPanel/icons/settings.png", 
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/home/picon/piconastra23.sh -O - | /bin/sh",
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/home/picon/piconastra23_uninstall.sh -O - | /bin/sh",
     "23.5E Picon", "picon", "picon-23.5e"),
    
    ("46E Picon", "/usr/lib/enigma2/python/Plugins/Extensions/CanPanel/icons/settings.png", 
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/home/picon/piconhotbird46.sh -O - | /bin/sh",
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/home/picon/piconhotbird46_uninstall.sh -O - | /bin/sh",
     "46E Picon", "picon", "picon-46e"),
    
    ("39E Picon", "/usr/lib/enigma2/python/Plugins/Extensions/CanPanel/icons/settings.png", 
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/home/picon/piconhotbird39.sh -O - | /bin/sh",
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/home/picon/piconhotbird39_uninstall.sh -O - | /bin/sh",
     "39E Picon", "picon", "picon-39e"),
    
    ("26E Picon", "/usr/lib/enigma2/python/Plugins/Extensions/CanPanel/icons/settings.png", 
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/home/picon/piconhotbird26.sh -O - | /bin/sh",
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/home/picon/piconhotbird26_uninstall.sh -O - | /bin/sh",
     "26E Picon", "picon", "picon-26e"),
    
    ("1.9E Picon", "/usr/lib/enigma2/python/Plugins/Extensions/CanPanel/icons/settings.png", 
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/home/picon/piconhotbird1.9.sh -O - | /bin/sh",
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/home/picon/piconhotbird1.9_uninstall.sh -O - | /bin/sh",
     "1.9E Picon", "picon", "picon-1.9e"),
    
    ("9E Picon", "/usr/lib/enigma2/python/Plugins/Extensions/CanPanel/icons/settings.png", 
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/home/picon/piconhotbird9.sh -O - | /bin/sh",
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/home/picon/piconhotbird9_uninstall.sh -O - | /bin/sh",
     "9E Picon", "picon", "picon-9e"),
    
    ("OpenAtv Devel Sürüm", "/usr/lib/enigma2/python/Plugins/Extensions/CanPanel/icons/openatv.png", 
     "wget -O - -q https://feeds2.mynonpublic.com/devel-feed | bash",
     "wget -O - -q https://feeds2.mynonpublic.com/devel-feed-uninstall | bash",
     "OpenAtv Devel Sürüm", "system", "openatv-devel"),
     
    ("OpenPli Menu Dili Yama", "/usr/lib/enigma2/python/Plugins/Extensions/CanPanel/icons/openpli.png", 
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/home/cevrimici/OpenPli-1.1_tr.sh -O - | /bin/sh",
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/home/cevrimici/OpenPli-1.1_tr_uninstall.sh -O - | /bin/sh",
     "OpenPli Menu Dili Yama", "system", "openpli-menu-dili"),
    
    ("OpenBh Menu Dili yama", "/usr/lib/enigma2/python/Plugins/Extensions/CanPanel/icons/openbh.png", 
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/home/cevrimici/OpenBH-1.1_tr.sh -O - | /bin/sh",
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/home/cevrimici/OpenBH-1.1_tr_uninstall.sh -O - | /bin/sh",
     "OpenBh Menu Dili yama", "system", "openbh-menu-dili"),
    
    ("OpenATV Menu Dili Yama", "/usr/lib/enigma2/python/Plugins/Extensions/CanPanel/icons/openatv.png", 
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/home/cevrimici/Openatv-1.1_tr.sh -O - | /bin/sh",
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/home/cevrimici/Openatv-1.1_tr_uninstall.sh -O - | /bin/sh",
     "OpenATV Menu Dili Yama", "system", "cevrimici-flash"),
  
    ("Uzum Sepeti", "/usr/lib/enigma2/python/Plugins/Extensions/CanPanel/icons/hediye.png", 
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/home/uygulama/playlists_can.sh -O - | /bin/sh",
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/home/uygulama/playlists_can_uninstall.sh -O - | /bin/sh",
     "Uzum Sepeti", "utility", "uzum-sepeti"),
    
    ("NexaTV Live", "/usr/lib/enigma2/python/Plugins/Extensions/CanPanel/icons/nexa.png", 
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/home/uygulama/NexaTV.sh -O - | /bin/sh",
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/home/uygulama/NexaTV_uninstall.sh -O - | /bin/sh",
     "NexaTV Live", "iptv", "nexatv-live"),
    
    ("OpevATV 7.6 Cevrimici Flas", "/usr/lib/enigma2/python/Plugins/Extensions/CanPanel/icons/openatv.png", 
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/home/cevrimici/Openatv_7.6.sh -O - | /bin/sh",
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/home/cevrimici/Openatv_7.6_uninstall.sh -O - | /bin/sh",
     "Cevrimici Flas", "software", "cevrimici-flash"),
    
    ("OpevATV 7.5 Cevrimici Flas", "/usr/lib/enigma2/python/Plugins/Extensions/CanPanel/icons/openatv.png", 
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/home/cevrimici/Openatv_7.5.2.sh -O - | /bin/sh",
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/home/cevrimici/Openatv_7.5.2_uninstall.sh -O - | /bin/sh",
     "Cevrimici Flas", "software", "cevrimici-flash"),
    
    ("OpevATV 7.4 Cevrimici Flas", "/usr/lib/enigma2/python/Plugins/Extensions/CanPanel/icons/openatv.png", 
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/home/cevrimici/Openatv_7.4.sh -O - | /bin/sh",
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/home/cevrimici/Openatv_7.4_uninstall.sh -O - | /bin/sh",
     "Cevrimici Flas", "software", "cevrimici-flash"),
    
    ("OpevPLI 9.2 Cevrimici Flas", "/usr/lib/enigma2/python/Plugins/Extensions/CanPanel/icons/openpli.png", 
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/home/cevrimici/OpenPLI_9.2.sh -O - | /bin/sh",
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/home/cevrimici/OpenPLI_9.2_uninstall.sh -O - | /bin/sh",
     "Cevrimici Flas", "software", "cevrimici-flash"),
             
    ("plugins sıfırla", "/usr/lib/enigma2/python/Plugins/Extensions/CanPanel/icons/CanPanel.png", 
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/cevrimici/CanPanel_Sifirla.sh -O - | /bin/sh",
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/cevrimici/CanPanel_Sifirla.sh -O - | /bin/sh",
     "CanPanel sıfırla", "system", "cevrimici-flash"),
     
     ("DostPortal Yaması WebBrowser", "/usr/lib/enigma2/python/Plugins/Extensions/CanPanel/icons/settings.png", 
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/home/Chromium/chromium2_Yama.sh -O - | /bin/sh",
     "wget -q --no-check-certificate http://grbz.com.tr/apps/CANPANEL/home/Chromium/chromium2_uninstall.sh -O - | /bin/sh",
     "Musa0124", "system", "cevrimici-flash"),
     
    ("Türkiye TV", "/usr/lib/enigma2/python/Plugins/Extensions/CanPanel/icons/turkıyetv.png", 
     "wget http://grbz.com.tr/apps/CANPANEL/home/uygulama/turkıyetv.sh -O - | /bin/sh",
     "wget http://grbz.com.tr/apps/CANPANEL/home/uygulama/turkıyetv_uninstall.sh -O - | /bin/sh",
     "Smlbird", "usta", "enigma2-plugin-turkıyetv"),  
     
    ("Ezan Vakti", "/usr/lib/enigma2/python/Plugins/Extensions/CanPanel/icons/EzanVakti.png", 
     "wget http://grbz.com.tr/apps/CANPANEL/home/uygulama/EzanVakti.sh -O - | /bin/sh",
     "wget http://grbz.com.tr/apps/CANPANEL/home/uygulama/EzanVakti_uninstall.sh -O - | /bin/sh",
     "Smlbird", "usta", "enigma2-plugin-EzanVakti"),  
] 
def load_pictures_map():
    pictures_map = {}
    for path in PICTURES_FILE_PATHS:
        if os.path.exists(path):
            try:
                with open(path, "r", encoding="utf-8") as f:
                    current_plugin = None
                    for line in f.read().splitlines():
                        line = line.strip()
                        if not line:
                            continue
                        if line.endswith(":"):
                            current_plugin = line[:-1].strip().lower()
                            pictures_map[current_plugin] = []
                        elif current_plugin and line.startswith("http"):
                            pictures_map[current_plugin].append(line)
                    logger.info(f"Loaded images for {len(pictures_map)} plugins from pictures.txt")
                    return pictures_map
            except Exception as e:
                logger.error(f"Error reading pictures.txt at {path}: {str(e)}")
    logger.warning("pictures.txt not found in any expected location.")
    return pictures_map

PICTURES_MAP = load_pictures_map()

def load_selected_language(available_languages):
    logger.info(f"Attempting to load language from {LANGUAGE_FILE}")
    if os.path.exists(LANGUAGE_FILE):
        try:
            with open(LANGUAGE_FILE, "r", encoding="utf-8") as f:
                line = f.readline().strip()
                if line:
                    lang_code = line.split("-")[-1].strip()
                    if lang_code in available_languages:
                        logger.debug(f"Loaded language from file: {lang_code}")
                        return lang_code
                    else:
                        logger.warning(f"Invalid language code in {LANGUAGE_FILE}: {lang_code}")
        except Exception as e:
            logger.error(f"Error reading {LANGUAGE_FILE}: {str(e)}")
    else:
        logger.debug(f"No language file found at {LANGUAGE_FILE}")
    return None

def getAvailableLanguages():
    desc_path = "/usr/lib/enigma2/python/Plugins/Extensions/CanPanel/descriptions/"
    logger.info(f"Checking for languages in {desc_path}")
    if os.path.exists(desc_path):
        folders = [f for f in os.listdir(desc_path) if os.path.isdir(os.path.join(desc_path, f))]
        language_choices = [(f, f"{f.capitalize()} - {f}") for f in folders]
        if not language_choices:
            language_choices = [("tr", "Turkce - tr")]
        logger.debug(f"Available languages: {language_choices}")
        return language_choices
    logger.warning(f"Descriptions path not found: {desc_path}")
    return [("tr", "Turkce - tr")]

language_choices = getAvailableLanguages()
config.plugins.CanPanel.language.choices = language_choices

def get_installed_plugins():
    installed = set()
    # Dosya yoksa oluştur
    if not os.path.exists(INSTALLED_PLUGINS_FILE):
        try:
            plugin_dir = os.path.dirname(INSTALLED_PLUGINS_FILE)
            if not os.path.exists(plugin_dir):
                os.makedirs(plugin_dir, exist_ok=True)
            # Boş dosya oluştur
            with open(INSTALLED_PLUGINS_FILE, "w", encoding="utf-8") as f:
                f.write("")
            logger.info(f"Created installed plugins file: {INSTALLED_PLUGINS_FILE}")
        except Exception as e:
            logger.error(f"Error creating installed plugins file: {str(e)}")
    else:
        try:
            with open(INSTALLED_PLUGINS_FILE, "r", encoding="utf-8") as f:
                for line in f:
                    plugin_name = line.strip()
                    if plugin_name:
                        installed.add(plugin_name)
        except Exception as e:
            logger.error(f"Error reading installed plugins: {str(e)}")
    return installed

INSTALLED_PLUGINS = get_installed_plugins()

class CategorySelectionScreen(Screen):
    skin = """
    <screen name="CategorySelectionScreen" position="center,center" size="900,700" title="Kategori Secimi" backgroundColor="#000000" flags="wfNoBorder">
        <eLabel position="0,0" size="900,700" zPosition="-2" backgroundColor="#0a0a12" />
        <eLabel position="0,0" size="900,700" zPosition="-1" backgroundColor="#0f1218" />
        
        <eLabel position="0,0" size="900,100" zPosition="0" backgroundColor="#12121f" />
        <eLabel position="0,95" size="900,5" zPosition="1" backgroundColor="#3b82f6" />
        
        <widget name="title" position="50,30" size="800,60" zPosition="2" font="Regular;36" foregroundColor="#ffffff" valign="center" backgroundColor="#12121f" />
        
        <eLabel position="50,120" size="800,520" zPosition="1" backgroundColor="#14161f" />
        <eLabel position="60,130" size="780,500" zPosition="2" backgroundColor="#0d0f14" />
        
        <widget name="categorylist" position="60,130" size="760,500" zPosition="3" itemHeight="80" scrollbarMode="showOnDemand" backgroundColor="#0d0f14" />
        
        <eLabel position="0,650" size="900,50" zPosition="3" backgroundColor="#0a0c12" />
        <eLabel position="0,650" size="900,3" zPosition="4" backgroundColor="#3b82f6" />
        
        <ePixmap position="50,660" size="32,32" zPosition="5" pixmap="/usr/share/enigma2/skin_default/buttons/red.png" alphatest="blend" />
        <widget name="key_red" position="100,655" size="200,40" zPosition="6" font="Regular;24" foregroundColor="#ef4444" halign="left" valign="center" backgroundColor="#0a0c12" />
        
        <eLabel position="600,655" size="250,40" zPosition="6" backgroundColor="#1a1a2e" />
        <ePixmap position="610,662" size="32,32" zPosition="7" pixmap="/usr/share/enigma2/skin_default/buttons/green.png" alphatest="blend" />
        <widget name="key_green" position="660,655" size="180,40" zPosition="8" font="Regular;24" foregroundColor="#22c55e" halign="left" valign="center" backgroundColor="#1a1a2e" />
        
        <eLabel position="250,660" size="340,40" zPosition="6" backgroundColor="#1a1a2e" />
        <widget name="selection_info" position="260,665" size="320,30" zPosition="7" font="Regular;18" foregroundColor="#f59e0b" halign="center" valign="center" backgroundColor="#1a1a2e" />
    </screen>"""
    
    def __init__(self, session, current_category="all"):
        Screen.__init__(self, session)
        self.session = session
        self.current_category = current_category
        
        self["title"] = Label("KATEGORI SECIMI")
        self["key_red"] = Label("GERI")
        self["key_green"] = Label("SEC")
        self["selection_info"] = Label("")
        self["categorylist"] = MenuList([], enableWrapAround=True, content=eListboxPythonMultiContent)
        self["categorylist"].l.setFont(0, gFont("Regular", 38))
        self["categorylist"].l.setFont(1, gFont("Regular", 42))
        self["categorylist"].l.setItemHeight(90)
        
        self.buildCategoryList()
        self["categorylist"].onSelectionChanged.append(self.onSelectionChanged)
        
        self["actions"] = ActionMap(["OkCancelActions", "ColorActions"], {
            "cancel": self.exit,
            "red": self.exit,
            "ok": self.selectCategory,
            "green": self.selectCategory,
        }, -2)
        
        self.onLayoutFinish.append(self.onLayoutFinished)
    
    def onLayoutFinished(self):
        self.setCurrentCategory()
    
    def setCurrentCategory(self):
        category_names = [cat[0] for cat in CATEGORIES]
        if self.current_category in category_names:
            index = category_names.index(self.current_category)
            self["categorylist"].setTopIndex(max(0, index - 2))
            # İlk seçimi göster
            current = self["categorylist"].getCurrent()
            if current and len(current) > 0:
                cat_name = current[0][1]
                self["selection_info"].setText(f"Secili: {cat_name}")
    
    def buildCategoryList(self):
        category_data = []
        for cat_id, cat_name, cat_icon in CATEGORIES:
            entry = self.buildCategoryEntry(cat_id, cat_name, cat_icon)
            category_data.append(entry)
        self["categorylist"].setList(category_data)
        logger.info(f"Built category list with {len(CATEGORIES)} categories")
    
    def buildCategoryEntry(self, cat_id, cat_name, cat_icon):
        res = [(cat_id, cat_name, cat_icon)]
        
        # Seçim işaretçisi (▶) - sadece seçili öğede görünür
        res.append(MultiContentEntryText(
            pos=(15, 20),
            size=(50, 50),
            font=1,
            text="▶ ",
            flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER,
            color=0x000000,  # Normalde siyah (görünmez)
            color_sel=0x22c55e  # Seçiliyken yeşil
        ))
        
        # Kategori ikonu
        if os.path.exists(cat_icon):
            try:
                pixmap = LoadPixmap(cat_icon)
                if pixmap:
                    res.append(MultiContentEntryPixmapAlphaTest(
                        pos=(75, 18),
                        size=(55, 55),
                        png=pixmap
                    ))
            except Exception as e:
                logger.debug(f"Error loading category icon {cat_icon}: {str(e)}")
        
        # Kategori adı - seçiliyken daha büyük ve beyaz
        res.append(MultiContentEntryText(
            pos=(145, 20),
            size=(580, 55),
            font=1,
            text=cat_name,
            flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER,
            color=0x888888,  # Normalde gri
            color_sel=0xffffff  # Seçiliyken beyaz
        ))
        
        return res
    
    def onSelectionChanged(self):
        current = self["categorylist"].getCurrent()
        if current and len(current) > 0:
            cat_name = current[0][1]
            self["selection_info"].setText(f"Secili: {cat_name}")
    
    def selectCategory(self):
        current = self["categorylist"].getCurrent()
        if current and len(current) > 0:
            cat_id = current[0][0]
            self.close(cat_id)
    
    def exit(self):
        self.close(None)

class ImageViewerScreen(Screen):
    skin = """
    <screen name="ImageViewerScreen" position="center,center" size="1400,800" title="Resim Goruntuleyici" backgroundColor="#000000" flags="wfNoBorder">
        <eLabel position="0,0" size="1400,800" zPosition="0" backgroundColor="#0a0a12" />
        <eLabel position="0,0" size="1400,800" zPosition="1" backgroundColor="#12121f" />
        
        <eLabel position="-100,-100" size="400,400" zPosition="1" backgroundColor="#1a1a3e" />
        <eLabel position="1100,600" size="400,400" zPosition="1" backgroundColor="#1a1a3e" />
        
        <eLabel position="100,80" size="1200,550" zPosition="2" backgroundColor="#1a1a2e" />
        <eLabel position="110,90" size="1180,530" zPosition="3" backgroundColor="#0d0d18" />
        <eLabel position="110,90" size="1180,530" zPosition="4" backgroundColor="#000000" alphatest="blend" />
        
        <widget name="image" position="120,100" size="1160,510" zPosition="5" alphatest="on" scale="1" backgroundColor="#0d0d18" />
        
        <eLabel position="1150,85" size="140,40" zPosition="6" backgroundColor="#1e3a5f" />
        <eLabel position="1150,85" size="140,40" zPosition="7" backgroundColor="#000000" alphatest="blend" />
        <widget name="image_label" position="1160,87" size="120,36" zPosition="8" font="Regular;22" halign="center" valign="center" foregroundColor="#ffffff" backgroundColor="#1e3a5f" />
        
        <eLabel position="0,700" size="1400,100" zPosition="3" backgroundColor="#0a0a12" />
        <eLabel position="0,700" size="1400,3" zPosition="4" backgroundColor="#3b82f6" />
        
        <eLabel position="200,720" size="200,55" zPosition="5" backgroundColor="#1a1a2e" />
        <eLabel position="450,720" size="200,55" zPosition="5" backgroundColor="#1a1a2e" />
        <eLabel position="700,720" size="200,55" zPosition="5" backgroundColor="#1a1a2e" />
        
        <ePixmap position="220,730" size="36,36" zPosition="6" pixmap="/usr/share/enigma2/skin_default/buttons/red.png" alphatest="blend" />
        <widget name="key_red" position="270,725" size="150,36" zPosition="7" font="Regular;26" foregroundColor="#ef4444" halign="left" valign="center" backgroundColor="#1a1a2e" />
        
        <ePixmap position="470,730" size="36,36" zPosition="6" pixmap="/usr/share/enigma2/skin_default/buttons/green.png" alphatest="blend" />
        <widget name="key_green" position="520,725" size="180,36" zPosition="7" font="Regular;26" foregroundColor="#22c55e" halign="left" valign="center" backgroundColor="#1a1a2e" />
        
        <ePixmap position="720,730" size="36,36" zPosition="6" pixmap="/usr/share/enigma2/skin_default/buttons/blue.png" alphatest="blend" />
        <widget name="key_blue" position="770,725" size="180,36" zPosition="7" font="Regular;26" foregroundColor="#3b82f6" halign="left" valign="center" backgroundColor="#1a1a2e" />
        
        <eLabel position="0,30" size="1400,50" zPosition="2" backgroundColor="#12121f" />
        <eLabel position="0,75" size="1400,5" zPosition="3" backgroundColor="#3b82f6" />
        <widget name="title" position="50,35" size="1100,40" zPosition="4" font="Regular;32" foregroundColor="#ffffff" valign="center" backgroundColor="#12121f" />
    </screen>"""
    
    def __init__(self, session, image_urls, plugin_name):
        Screen.__init__(self, session)
        self.session = session
        self.image_urls = image_urls
        self.current_index = 0
        self.plugin_name = plugin_name
        self.temp_files = []
        self["image"] = Pixmap()
        self["image_label"] = Label()
        self["title"] = Label(f"{plugin_name}")
        self["key_red"] = Label("CIKIS")
        self["key_green"] = Label("ONCEKI")
        self["key_blue"] = Label("SONRAKI")
        self["actions"] = ActionMap(["OkCancelActions", "ColorActions", "DirectionActions"], {
            "cancel": self.exit,
            "red": self.exit,
            "green": self.prevImage,
            "blue": self.nextImage,
            "left": self.prevImage,
            "right": self.nextImage,
        }, -2)
        self.onLayoutFinish.append(self.showImage)
    
    def download_image(self, url):
        temp_file = f"/tmp/canpanel_image_{uuid.uuid4().hex}.jpg"
        try:
            urllib.request.urlretrieve(url, temp_file)
            if os.path.exists(temp_file):
                self.temp_files.append(temp_file)
                logger.debug(f"Image downloaded to {temp_file}")
                return temp_file
        except Exception as e:
            logger.error(f"Error downloading image {url}: {str(e)}")
        return None
    
    def showImage(self):
        if not self.image_urls:
            self["image_label"].setText(f"{self.plugin_name} icin resim bulunamadi")
            return
        image_url = self.image_urls[self.current_index]
        temp_file = self.download_image(image_url)
        if temp_file and os.path.exists(temp_file):
            pixmap = LoadPixmap(temp_file)
            if pixmap:
                self["image"].instance.setPixmap(pixmap)
                self["image_label"].setText(f"{self.current_index + 1}/{len(self.image_urls)}")
            else:
                self["image_label"].setText("Resim yuklenemedi")
                logger.error(f"Pixmap load failed: {temp_file}")
        else:
            self["image_label"].setText("Resim indirilemedi")
            logger.error(f"Download failed: {image_url}")
    
    def nextImage(self):
        if self.image_urls:
            self.current_index = (self.current_index + 1) % len(self.image_urls)
            self.showImage()
    
    def prevImage(self):
        if self.image_urls:
            self.current_index = (self.current_index - 1) % len(self.image_urls)
            self.showImage()
    
    def exit(self):
        for temp_file in self.temp_files:
            try:
                if os.path.exists(temp_file):
                    os.remove(temp_file)
            except Exception as e:
                logger.error(f"Error removing temp file {temp_file}: {str(e)}")
        self.close()

class DownloadProgressScreen(Screen):
    skin = """
    <screen name="DownloadProgressScreen" position="center,center" size="700,400" title="Indirme Durumu" backgroundColor="#000000" flags="wfNoBorder">
        <eLabel position="0,0" size="700,400" zPosition="-2" backgroundColor="#0a0a12" />
        <eLabel position="0,0" size="700,400" zPosition="-1" backgroundColor="#12121f" />
        
        <eLabel position="0,0" size="700,80" zPosition="0" backgroundColor="#12121f" />
        <eLabel position="0,75" size="700,5" zPosition="1" backgroundColor="#3b82f6" />
        
        <widget name="title" position="50,20" size="600,50" zPosition="2" font="Regular;28" foregroundColor="#ffffff" valign="center" backgroundColor="#12121f" />
        
        <eLabel position="50,120" size="600,150" zPosition="1" backgroundColor="#1a1a2e" />
        <eLabel position="60,130" size="580,130" zPosition="2" backgroundColor="#0d0d18" />
        
        <widget name="progress" position="80,150" size="540,30" zPosition="3" />
        <widget name="progress_label" position="80,190" size="540,30" zPosition="4" font="Regular;22" foregroundColor="#60a5fa" halign="center" valign="center" backgroundColor="#0d0d18" />
        <widget name="percentage" position="80,230" size="540,30" zPosition="4" font="Regular;24" foregroundColor="#22c55e" halign="center" valign="center" backgroundColor="#0d0d18" />
        
        <eLabel position="50,300" size="600,80" zPosition="1" backgroundColor="#1a1a2e" />
        <widget name="status" position="70,320" size="560,45" zPosition="2" font="Regular;22" foregroundColor="#8b98a5" halign="center" valign="center" backgroundColor="#1a1a2e" />
    </screen>"""
    
    def __init__(self, session, plugin_name):
        Screen.__init__(self, session)
        self.session = session
        self.plugin_name = plugin_name
        self.current_progress = 0
        
        self["title"] = Label(f"{plugin_name}")
        self["progress"] = Slider(min=0, max=100)
        self["progress_label"] = Label("Hazirlaniyor...")
        self["percentage"] = Label("0%")
        self["status"] = Label("Lutfen bekleyiniz")
        
        self["actions"] = ActionMap(["OkCancelActions"], {
            "cancel": self.cancelDownload,
        }, -2)
        
        self.download_timer = eTimer()
        self.download_timer.callback.append(self.updateProgress)
        self.download_timer.start(100, True)
    
    def updateProgress(self):
        self.current_progress += 2
        if self.current_progress > 100:
            self.current_progress = 100
        
        self["progress"].setValue(self.current_progress)
        self["percentage"].setText(f"{self.current_progress}%")
        
        if self.current_progress < 30:
            self["progress_label"].setText("Baglanti kuruluyor...")
            self["status"].setText("Sunucuyla iletisime geçiliyor")
        elif self.current_progress < 60:
            self["progress_label"].setText("Dosya indiriliyor...")
            self["status"].setText("Veri aktarimi devam ediyor")
        elif self.current_progress < 90:
            self["progress_label"].setText("Dosya isleniyor...")
            self["status"].setText("Kurulum dosyalari hazirlaniyor")
        else:
            self["progress_label"].setText("Kurulum tamamlaniyor...")
            self["status"].setText("Son adimlar gerceklestiriliyor")
        
        if self.current_progress < 100:
            self.download_timer.start(150, True)
        else:
            self.download_timer.stop()
    
    def setProgress(self, value):
        self.current_progress = value
        self["progress"].setValue(value)
        self["percentage"].setText(f"{value}%")
        
        if value < 30:
            self["progress_label"].setText("Baglanti kuruluyor...")
            self["status"].setText("Sunucuyla iletisime geçiliyor")
        elif value < 60:
            self["progress_label"].setText("Dosya indiriliyor...")
            self["status"].setText("Veri aktarimi devam ediyor")
        elif value < 90:
            self["progress_label"].setText("Dosya isleniyor...")
            self["status"].setText("Kurulum dosyalari hazirlaniyor")
        else:
            self["progress_label"].setText("Kurulum tamamlaniyor...")
            self["status"].setText("Son adimlar gerceklestiriliyor")
    
    def cancelDownload(self):
        self.download_timer.stop()
        self.close(False)

class CanPanelList(Screen):
    skin = """
    <screen name="CanPanelList" position="center,center" size="1750,980" title="Can Panel" backgroundColor="#051026" flags="wfNoBorder">
        <!-- Ana arka plan - derin lacivert -->
        <eLabel position="0,0" size="1750,980" zPosition="-1" backgroundColor="#051026" />
        
        <!-- Header - Modern gradient -->
        <eLabel position="0,0" size="1750,2" zPosition="1" backgroundColor="#1a4070" />
        <eLabel position="0,2" size="1750,78" zPosition="0" backgroundColor="#0d1f3d" />
        <eLabel position="0,78" size="1750,2" zPosition="1" backgroundColor="#00d4ff" />
        
        <!-- Logo alani - BÜYÜK 120x70 -->
        <eLabel position="20,5" size="120,70" zPosition="1" backgroundColor="#1a3a5f" />
        <eLabel position="22,7" size="3,66" zPosition="3" backgroundColor="#00d4ff" />
        <widget name="logo_icon" position="25,5" size="120,70" zPosition="4" alphatest="blend" />
        
        <!-- Baslik Card - Modern -->
         <widget name="title" position="170,17" size="370,25" zPosition="4" font="Regular;26" foregroundColor="#FFFFFF" halign="left" valign="center" transparent="1" />
        <widget name="subtitle" position="170,48" size="300,22" zPosition="4" font="Regular;18" foregroundColor="#00ffff" halign="left" valign="center" transparent="1" />
        
        <!-- Saat Card - Modern -->
        <eLabel position="1380,15" size="350,50" zPosition="1" backgroundColor="#1a3a5f" />
        <eLabel position="1382,17" size="3,46" zPosition="3" backgroundColor="#00d4ff" />
        <widget name="header_time" position="1390,20" size="330,40" zPosition="4" font="Regular;28" foregroundColor="#00ffff" halign="center" valign="center" backgroundColor="#1a3a5f" />
        
        <!-- Sol Panel - Modern -->
       <eLabel position="20,95" size="3,740" zPosition="2" backgroundColor="#00d4ff" />
        
        <!-- Kategori Başlık Card -->
        <eLabel position="25,95" size="430,45" zPosition="2" backgroundColor="#1a3a5f" />
          <widget name="list_title" position="40,102" size="390,30" zPosition="4" font="Regular;26" foregroundColor="#00ffff" halign="center" valign="center" backgroundColor="#1a3a5f" />
        
        <!-- Aktif Panel Göstergesi -->
              <widget name="panel_indicator" position="40,867" size="390,30" zPosition="4" font="Regular;22" foregroundColor="#00ff00" halign="center" valign="center" backgroundColor="#1a3a5f" />
        
        <!-- Kategori listesi -->
        <widget name="catlist" position="30,150" size="420,670" zPosition="5" itemHeight="75" scrollbarMode="showOnDemand" foregroundColor="#d0e0f0" backgroundColorSelected="#1a4070" foregroundColorSelected="#ffffff" transparent="1" />
        
        
        <!-- Plugin Başlık Card -->
        <eLabel position="495,95" size="580,45" zPosition="2" backgroundColor="#1a3a5f" />
          <widget name="info_title" position="500,102" size="550,40" zPosition="4" font="Regular;28" foregroundColor="#00ffff" halign="left" valign="center" backgroundColor="#1a3a5f" />
        
        <!-- Plugin Sayısı Badge -->
          <widget name="plugin_count" position="1465,112" size="190,30" zPosition="4" font="Regular;18" foregroundColor="#00ffff" halign="center" valign="center" backgroundColor="#1a3a5f" />
        
        <!-- Plugin listesi -->
        <widget name="pluginlist" position="495,160" size="1220,675" zPosition="5" itemHeight="75" scrollbarMode="showOnDemand" foregroundColor="#e0e8f0" backgroundColorSelected="#1a4070" foregroundColorSelected="#ffffff" transparent="1"  />
        
        <!-- Footer - Modern gradient -->
        <eLabel position="0,850" size="1750,2" zPosition="2" backgroundColor="#1a4070" />
        <eLabel position="0,852" size="1750,128" zPosition="1" backgroundColor="#0d1f3d" />
        <eLabel position="0,975" size="1750,5" zPosition="2" backgroundColor="#00d4ff" />
        
        <!-- Durum göstergesi - Modern badge -->
           <widget name="status_label" position="40,910" size="390,34" zPosition="5" font="Regular;20" foregroundColor="#00ffff" halign="left" valign="center" backgroundColor="#1a3a5f" />
        
        <!-- Modern Butonlar - Sleek Design -->
        <!-- GERİ - Kırmızı -->
        <eLabel position="540,870" size="220,50" zPosition="3" backgroundColor="#c41e3a" />
        <eLabel position="540,870" size="220,50" zPosition="4" borderWidth="2" borderColor="#ff4d6a" borderStyle="solid" radius="12" />
        <eLabel position="542,872" size="3,46" zPosition="5" backgroundColor="#ff4d6a" />
        <widget name="key_red" position="540,870" size="220,50" zPosition="6" font="Regular;22" foregroundColor="#ffffff" halign="center" valign="center" backgroundColor="#c41e3a" />
        
        <!-- YÜKLE - Yeşil -->
        <eLabel position="780,870" size="220,50" zPosition="3" backgroundColor="#28a745" />
        <eLabel position="780,870" size="220,50" zPosition="4" borderWidth="2" borderColor="#5dff7d" borderStyle="solid" radius="12" />
        <eLabel position="782,872" size="3,46" zPosition="5" backgroundColor="#5dff7d" />
        <widget name="key_green" position="780,870" size="220,50" zPosition="6" font="Regular;22" foregroundColor="#ffffff" halign="center" valign="center" backgroundColor="#28a745" />
        
        <!-- YENİLE - Turuncu -->
        <eLabel position="1020,870" size="220,50" zPosition="3" backgroundColor="#ff8c00" />
        <eLabel position="1020,870" size="220,50" zPosition="4" borderWidth="2" borderColor="#ffb84d" borderStyle="solid" radius="12" />
        <eLabel position="1022,872" size="3,46" zPosition="5" backgroundColor="#ffb84d" />
        <widget name="key_yellow" position="1020,870" size="220,50" zPosition="6" font="Regular;22" foregroundColor="#ffffff" halign="center" valign="center" backgroundColor="#ff8c00" />
        
        <!-- AYARLAR - Mavi -->
        <eLabel position="1260,870" size="220,50" zPosition="3" backgroundColor="#007acc" />
        <eLabel position="1260,870" size="220,50" zPosition="4" borderWidth="2" borderColor="#4da6ff" borderStyle="solid" radius="12" />
        <eLabel position="1262,872" size="3,46" zPosition="5" backgroundColor="#4da6ff" />
        <widget name="key_blue" position="1260,870" size="220,50" zPosition="6" font="Regular;22" foregroundColor="#ffffff" halign="center" valign="center" backgroundColor="#007acc" />
    </screen>"""


    def __init__(self, session):
        Screen.__init__(self, session)
        self.session = session
        self.available_languages = [choice[0] for choice in getAvailableLanguages()]
        self.language = load_selected_language(self.available_languages)
        if not self.language:
            self.language = config.plugins.CanPanel.language.value or "tr"
        self.version_check_in_progress = False
        self.version_buffer = b''
        
        try:
            if os.path.exists(PICTURES_DIR):
                shutil.rmtree(PICTURES_DIR)
        except Exception as e:
            logger.error(f"Error removing pictures folder: {str(e)}")
        
        self["title"] = Label("CAN PANEL")
        self["subtitle"] = Label(f"Eklenti Yöneticisi v{PLUGIN_VERSION}")
        self["version"] = Label(f"v{PLUGIN_VERSION}")
        self["info_title"] = Label("Tüm Eklentiler")
        self["description"] = Label("")
        self["status_label"] = Label("Hazır - Seçim yapınız")
        self["list_title"] = Label("◈ KATEGORİLER")
        self["category_label"] = Label("")
        self["search_info"] = Label("")
        self["plugin_count"] = Label("Toplam: 0 Eklenti")
        self["header_time"] = Label("--:--:--")
        self["key_red"] = Label("✕ GERİ")
        self["key_green"] = Label("✓ YÜKLE")
        self["key_yellow"] = Label("↻ YENİLE")
        self["key_blue"] = Label("⚙ AYARLAR")
        self["logo_icon"] = Pixmap()
        self["panel_indicator"] = Label("► KATEGORİ PANELİ")
        
        self.all_plugins = PLUGIN_LIST
        self.filtered_plugins = []
        self.current_category = "all"
        self.current_search = ""
        self.plugin_data = []
        self["pluginlist"] = MenuList(self.plugin_data, enableWrapAround=True, content=eListboxPythonMultiContent)
        self["pluginlist"].l.setFont(0, gFont("Regular", 26))  # Plugin isimleri
        self["pluginlist"].l.setFont(1, gFont("Regular", 19))  # Alt yazılar (kategori tag)
        self["pluginlist"].l.setItemHeight(75)
        
        # Kategori listesi
        self.category_data = []
        self["catlist"] = MenuList([], enableWrapAround=True, content=eListboxPythonMultiContent)
        self["catlist"].l.setFont(0, gFont("Regular", 26))  # Kategori isimleri büyük font
        self["catlist"].l.setItemHeight(75)
        self.buildCategoryList()
        self["catlist"].onSelectionChanged.append(self.onCategoryChanged)
        
        # Aktif panel takibi
        self.active_panel = "categories"  # "plugins" veya "categories" - baslangicta kategoride
        
        # Mevcut kategoriye göre plugin listesini doldur (applyFilters ile)
        self.applyFilters()  # "all" kategorisi için tüm pluginleri yükle
        
        self["pluginlist"].onSelectionChanged.append(self.onPluginSelectionChanged)
        
        self["actions"] = ActionMap(["OkCancelActions", "ColorActions", "DirectionActions"], {
            "cancel": self.goBack,  # EXIT ile kategoriye geri dön veya çık
            "red": self.goBack,  # RED tuş da EXIT gibi çalışsın
            "green": self.installPlugin,
            "yellow": self.applyFilters,
            "blue": self.handleBlueKey,  # Bağlama duyarlı: Kategori=Ayarlar, Plugin=Resimler
            "ok": self.handleOk,
            "left": self.handleLeft,
            "right": self.handleRight,
            "up": self.handleUp,
            "down": self.handleDown,
        }, -2)
        
        self.container = eConsoleAppContainer()
        self.container.appClosed.append(self.command_finished)
        self.container.dataAvail.append(self.version_data_avail)
        
        self.restart_timer = None
        
        # Son seçili kategori index'i - geri dönüşte kullanılacak
        self.last_category_index = 0
        
        # goBack sırasında onCategoryChanged'in çalışmasını engellemek için flag
        self.in_go_back = False
        self.returning_from_plugins = False
        self.installing_plugin_name = None
        self.onLayoutFinish.append(self.onLayoutFinished)
        
        # Saat güncelleme timer'ı
        self.time_timer = eTimer()
        self.time_timer.callback.append(self.updateTime)
        self.time_timer.start(1000, False)  # Her saniye güncelle
        
        self.check_version_timer = eTimer()
        self.check_version_timer.callback.append(self.check_for_updates)
        self.check_version_timer.start(4000, True)
    
    def buildCategoryList(self):
        self.category_data = []
        for cat_id, cat_name, cat_icon in CATEGORIES:
            entry = self.buildCategoryEntry(cat_id, cat_name, cat_icon)
            self.category_data.append(entry)
        self["catlist"].setList(self.category_data)
        logger.info(f"Built category list with {len(CATEGORIES)} categories")
    
    def buildCategoryEntry(self, cat_id, cat_name, cat_icon):
        res = [(cat_id, cat_name, cat_icon)]
        
        # Ana arka plan - koyu lacivert
        res.append(MultiContentEntryText(
            pos=(0, 0),
            size=(350, 75),
            font=0,
            text=" ",
            flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER,
            color=0x0a2540,
            color_sel=0x0066cc
        ))
        
        # Secili item icin border efekti
        res.append(MultiContentEntryText(
            pos=(0, 0),
            size=(350, 75),
            font=0,
            text=" ",
            flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER,
            color=0x2a5a8a,
            color_sel=0x66b3ff
        ))
        
        # Sol accent çizgi - minimalist ama belirgin
        res.append(MultiContentEntryText(
            pos=(0, 0),
            size=(4, 75),
            font=0,
            text=" ",
            flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER,
            color=0x0f2847,  # Normal: panel rengi
            color_sel=0x00ffff  # Seçili: parlak cyan
        ))
        
        # Kategori ikonu - solda (küçültülmüş)
        if os.path.exists(cat_icon):
            try:
                pixmap = LoadPixmap(cat_icon)
                if pixmap:
                    res.append(MultiContentEntryPixmapAlphaTest(
                        pos=(12, 12),
                        size=(50, 50),
                        png=pixmap
                    ))
            except Exception as e:
                logger.debug("Error loading category icon {}: {}".format(cat_icon, str(e)))
        
        # Kategori adi - Büyük harflerle
        res.append(MultiContentEntryText(
            pos=(75, 20),
            size=(250, 35),
            font=0,
            text=cat_name.upper(),
            flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER,
            color=0xb0c4de,
            color_sel=0xffffff
        ))
        
        # Ok işareti - sadece seçili olduğunda göster
        res.append(MultiContentEntryText(
            pos=(320, 20),
            size=(30, 35),
            font=0,
            text="▶",
            flags=RT_HALIGN_CENTER | RT_VALIGN_CENTER,
            color=0x0a1628,  # Normal: görünmez
            color_sel=0xffff00  # Seçili: SARI (çok belirgin)
        ))
        
        return res
    
    def onCategoryChanged(self):
        # Ekstra güvenlik kontrolleri - çökme önleme
        try:
            # goBack sırasında onCategoryChanged'in çalışmasını engelle
            if getattr(self, 'in_go_back', False):
                return
                
            # Sadece kategori panelindeyken çalış
            if self.active_panel != "categories":
                return
            
            # Widget'ın hazır olup olmadığını kontrol et
            catlist = self.getList()
            if not catlist or not hasattr(catlist, 'getCurrent'):
                return
            
            current = catlist.getCurrent()
            if not current or len(current) == 0:
                return
            
            cat_id = current[0][0]
            cat_name = current[0][1]
            current_idx = catlist.getSelectedIndex()
            
            # Son seçili kategori index'ini kaydet
            self.last_category_index = current_idx
            
            # Status label'ı güncelle - güvenli şekilde
            try:
                self["status_label"].setText(f"► {cat_name} - OK ile aç")
            except Exception:
                pass
            
            # Kategori değiştiğinde plugin listesini de güncelle (ama selection gösterme)
            self.current_category = cat_id
            self.applyFilters()
            # applyFilters içinde buildList çağrılıyor, bu da plugin listesini güncelliyor
            
        except Exception as e:
            logger.debug(f"onCategoryChanged error (non-critical): {str(e)}")
            # Hata olsa bile çökme - devam et
    
    def updatePluginPreview(self, category_id):
        """Kategori navigasyonunda plugin sayısını güncelle (liste değişmez)"""
        if self.active_panel == "categories":
            # Sadece sayıyı hesapla, listeyi değiştirme
            count = 0
            for plugin in self.all_plugins:
                if len(plugin) >= 7:
                    plugin_name, icon_path, install_cmd, uninstall_cmd, desc_file, category, package_name = plugin[:7]
                    if category_id == "all" or category == category_id:
                        count += 1
            
            self["plugin_count"].setText(f"Toplam: {count} Eklenti")
    
    def onLayoutFinished(self):
        # Başlangıçta kategori panelindeyiz
        self.active_panel = "categories"
        # Panel indicator'ı başlat
        self["panel_indicator"].setText("► KATEGORİ PANELİ")
        # İlk kategoriyi göster
        current = self["catlist"].getCurrent()
        if current and len(current) > 0:
            cat_name = current[0][1]
            self["info_title"].setText(cat_name)
            self["status_label"].setText(f"► {cat_name} - OK ile aç")
        self.refreshDescription()
        self.loadLogoIcon()
        logger.info("Layout finished, plugin v1.4.3 ready")
        
        # Liste hazır olduğunda plugin listesini yeniden oluştur (widget artık hazır)
        self.buildList()
        
        # Plugin sayisini guncelle
        self["plugin_count"].setText(f"Toplam: {len(self.filtered_plugins)} Eklenti")
        # Plugin list style'ı güncelle (kategori modunda selection rengi transparent)
        self.updatePluginListStyle()
    
    def loadLogoIcon(self):
        logo_path = "/usr/lib/enigma2/python/Plugins/Extensions/CanPanel/icons/CanPanel.png"
        if os.path.exists(logo_path):
            try:
                pixmap = LoadPixmap(logo_path)
                if pixmap:
                    self["logo_icon"].instance.setPixmap(pixmap)
            except Exception as e:
                logger.debug(f"Error loading logo icon: {str(e)}")
    
    def updateTime(self):
        """Saati her saniye güncelle"""
        try:
            from time import strftime
            current_time = strftime("%H:%M:%S")
            self["header_time"].setText(current_time)
        except Exception as e:
            logger.debug(f"Error updating time: {str(e)}")
    
    def applyFilters(self):
        try:
            self.filtered_plugins = []
            
            for plugin in self.all_plugins:
                if len(plugin) >= 7:
                    plugin_name, icon_path, install_cmd, uninstall_cmd, desc_file, category, package_name = plugin[:7]
                    
                    category_match = (self.current_category == "all") or (category == self.current_category)
                    search_match = True
                    
                    if self.current_search:
                        search_text = self.current_search.lower()
                        search_match = (search_text in plugin_name.lower() or 
                                       search_text in desc_file.lower() or
                                       search_text in category.lower())
                    
                    if category_match and search_match:
                        self.filtered_plugins.append(plugin)
            
            self.buildList()
            # Plugin sayisini guncelle - güvenli şekilde
            try:
                self["plugin_count"].setText(f"Toplam: {len(self.filtered_plugins)} Eklenti")
            except Exception:
                pass
            logger.info(f"Applied filters: category={self.current_category}, search='{self.current_search}', found={len(self.filtered_plugins)}")
        except Exception as e:
            logger.debug(f"applyFilters error (non-critical): {str(e)}")
    
    def buildList(self):
        try:
            self.plugin_data = []
            
            # Her zaman listeyi göster ama selection sadece plugin panelindeyken
            for plugin in self.filtered_plugins:
                if len(plugin) >= 7:
                    plugin_name, icon_path, install_cmd, uninstall_cmd, desc_file, category, package_name = plugin[:7]
                    is_installed = plugin_name in INSTALLED_PLUGINS
                    # Selection sadece plugin panelindeyken göster
                    show_selection = (self.active_panel == "plugins")
                    entry = self.buildListEntry(plugin_name, icon_path, install_cmd, desc_file, is_installed, show_selection)
                    self.plugin_data.append(entry)
            
            # Widget hazırsa listeyi güncelle
            plugin_list = self.getPluginList()
            if plugin_list:
                plugin_list.setList(self.plugin_data)
            
            # Plugin listesinin selection rengini güncelle
            self.updatePluginListStyle()
            
            logger.info(f"Built list with {len(self.plugin_data)} plugins, panel={self.active_panel}")
        except Exception as e:
            logger.debug(f"buildList error (non-critical): {str(e)}")
    
    def updatePluginListStyle(self):
        """Plugin listesinin selection stilini güncelle"""
        try:
            if hasattr(self["pluginlist"], "instance") and self["pluginlist"].instance:
                # Kategori modunda selection rengini transparent yap
                if self.active_panel == "categories":
                    self["pluginlist"].instance.setBackgroundColorSelected(0x000000)  # Siyah (görünmez)
                    self["pluginlist"].instance.setForegroundColorSelected(0x808080)  # Gri
                else:
                    # Plugin modunda normal renkleri kullan
                    self["pluginlist"].instance.setBackgroundColorSelected(0x1a4070)
                    self["pluginlist"].instance.setForegroundColorSelected(0xffffff)
        except Exception as e:
            logger.debug(f"Error updating plugin list style: {str(e)}")
    
    def getPluginList(self):
        """Plugin listesine güvenli erişim"""
        try:
            pl = self["pluginlist"]
            if pl and hasattr(pl, 'instance') and pl.instance:
                return pl
        except Exception:
            pass
        return None
    
    def getList(self):
        """Kategori listesine güvenli erişim"""
        try:
            cl = self["catlist"]
            if cl and hasattr(cl, 'instance') and cl.instance:
                return cl
        except Exception:
            pass
        return None
    
    def buildListEntry(self, plugin_name, icon_path, cmd, desc_file, is_installed=False, show_selection=True):
        res = [(plugin_name, cmd, is_installed)]
        
        # Arka plan widget tarafından yönetiliyor - transparent
        
        # Plugin ikonu - 120x70 boyutunda
        if os.path.exists(icon_path):
            try:
                pixmap = LoadPixmap(icon_path)
                if pixmap:
                    res.append(MultiContentEntryPixmapAlphaTest(
                        pos=(10, 2),
                        size=(120, 70),
                        png=pixmap
                    ))
            except Exception as e:
                logger.debug(f"Error loading icon {icon_path}: {str(e)}")
        
        # Plugin adi - icon sonrası
        res.append(MultiContentEntryText(
            pos=(140, 12),
            size=(850, 28),
            font=0,
            text=plugin_name,
            flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER,
            color=0xe0e8f0,
            color_sel=0xffffff if show_selection else 0xe0e8f0
        ))
        
        # Plugin açıklaması - altında göster
        category_text = desc_file if desc_file else "utility"
        
        # Kategori ismini Türkçeleştir
        category_map = {
            "iptv": "IPTV Panel",
            "softcam": "Softcam",
            "skin": "Arayüz",
            "backup": "Yedekleme",
            "utility": "Araçlar",
            "bootlogo": "Bootlogo",
            "picon": "Picon",
            "system": "Sistem"
        }
        display_category = category_map.get(category_text, category_text)
        
        res.append(MultiContentEntryText(
            pos=(140, 45),
            size=(900, 22),
            font=1,
            text=display_category,
            flags=RT_HALIGN_LEFT | RT_VALIGN_CENTER,
            color=0x66b3ff,
            color_sel=0x99ccff if show_selection else 0x66b3ff
        ))
        
        # Durum butonu
        if is_installed:
            status_text = "KURULU"
            status_color = 0x00ff00
            status_bg = 0x003300
        else:
            status_text = "YÜKLE"
            status_color = 0x66ccff
            status_bg = 0x003366
        
        res.append(MultiContentEntryText(
            pos=(1060, 15),
            size=(130, 45),
            font=0,
            text=status_text,
            flags=RT_HALIGN_CENTER | RT_VALIGN_CENTER,
            color=status_color,  # Normal
            color_sel=status_color  # Seçili de AYNI (bar kalkacak)
        ))
        
        return res
    
    def getCurrentPlugin(self):
        try:
            current = self["pluginlist"].getCurrent()
            if current and len(current) > 0:
                return current[0]
        except Exception:
            pass
        return None
    
    def getCurrentPluginFull(self):
        try:
            index = self["pluginlist"].getSelectionIndex()
            if index < len(self.filtered_plugins):
                return self.filtered_plugins[index]
        except Exception:
            pass
        return None
    
    def onPluginSelectionChanged(self):
        # Sadece plugin paneli aktifse refresh yap
        try:
            if self.active_panel == "plugins":
                self.refreshDescription()
        except Exception:
            pass
    
    def onSelectionChanged(self):
        # Eski metod - geriye uyumluluk için
        try:
            self.refreshDescription()
        except Exception:
            pass
    
    def refreshDescription(self):
        try:
            plugin = self.getCurrentPluginFull()
            if plugin and len(plugin) >= 7:
                plugin_name, icon_path, install_cmd, uninstall_cmd, desc_file, category, package_name = plugin[:7]
                self["info_title"].setText(plugin_name)
                self["status_label"].setText(f"► Seçili: {plugin_name}")
                
                # Plugin kurulu mu kontrol et ve butonu güncelle
                if plugin_name in INSTALLED_PLUGINS:
                    self["key_green"].setText("✓ KALDIR")
                else:
                    self["key_green"].setText("✓ YÜKLE")
            else:
                self["info_title"].setText("Tüm Eklentiler")
                self["status_label"].setText("Hazır - Seçim yapınız")
        except Exception:
            pass
    
    def openCategorySelection(self):
        self.session.openWithCallback(
            self.categorySelected,
            CategorySelectionScreen,
            current_category=self.current_category
        )
    
    def categorySelected(self, category_id):
        if category_id:
            # Son seçili kategori index'ini kaydet
            current_idx = self["catlist"].getSelectedIndex()
            self.last_category_index = current_idx
            
            self.current_category = category_id
            self.current_search = ""
            self.applyFilters()
            
            category_name = "Tüm Eklentiler"
            for cat_id, cat_name, cat_icon in CATEGORIES:
                if cat_id == category_id:
                    category_name = cat_name
                    break
            
            self["info_title"].setText(category_name)
            self["status_label"].setText(f"Kategori: {category_name}")
            
            logger.info(f"Category selected: {category_name} (index: {current_idx})")
    
    def openSearch(self):
        self.session.openWithCallback(
            self.runSearch,
            VirtualKeyBoard,
            title="Eklenti Ara...",
            text=""
        )
    
    def runSearch(self, search_text):
        if search_text is not None and search_text.strip():
            self.current_search = search_text.strip()
            self.current_category = "all"
            self.applyFilters()
            
            count = len(self.filtered_plugins)
            self["status_label"].setText(f"Arama sonucu: {count} eklenti bulundu")
            self["info_title"].setText("Arama Sonucu")
        else:
            if search_text is not None:
                self.current_search = ""
                self["status_label"].setText("Arama temizlendi")
    
    def openSettings(self):
        # AYARLAR butonu - menü aç
        choices = [("Dil Değiştir", "language"), ("Hakkında", "about")]
        self.session.openWithCallback(
            self.settingsCallback,
            ChoiceBox,
            title="Ayarlar",
            list=choices
        )
    
    def settingsCallback(self, choice):
        if choice:
            if choice[1] == "language":
                self.changeLanguage()
            elif choice[1] == "about":
                self.session.open(
                    MessageBox,
                    f"Can Panel v{PLUGIN_VERSION}\n\nEklenti Yöneticisi\n\nTüm eklentileri kolayca yönetin.",
                    MessageBox.TYPE_INFO
                )
    
    def changeLanguage(self):
        choices = [(lang[1], lang[0]) for lang in getAvailableLanguages()]
        self.session.openWithCallback(self.languageSelected, ChoiceBox, title="Dil Seçin", list=choices)
    
    def languageSelected(self, choice):
        if choice:
            selected_lang = choice[1]
            display_lang = choice[0]
            if selected_lang in self.available_languages:
                self.language = selected_lang
                config.plugins.CanPanel.language.value = self.language
                config.plugins.CanPanel.language.save()
                try:
                    with open(LANGUAGE_FILE, "w", encoding="utf-8") as f:
                        f.write(f"{display_lang}\n")
                except Exception as e:
                    logger.error(f"Error writing language file: {str(e)}")
                self.buildCategoryList()
                self.buildList()
                self["status_label"].setText(f"Dil değiştirildi: {display_lang}")
    
    def installPlugin(self):
        plugin = self.getCurrentPluginFull()
        if plugin and len(plugin) >= 7:
            plugin_name, icon_path, install_cmd, uninstall_cmd, desc_file, category, package_name = plugin[:7]
            
            global INSTALLED_PLUGINS
            INSTALLED_PLUGINS = get_installed_plugins()
            
            is_installed = plugin_name in INSTALLED_PLUGINS
            
            logger.info(f"installPlugin called for: {plugin_name}, is_installed: {is_installed}")
            
            if is_installed:
                self.uninstallPlugin(plugin, uninstall_cmd)
            else:
                self.showInstallConfirmation(plugin, install_cmd)
    
    def showInstallConfirmation(self, plugin, install_cmd):
        plugin_name = plugin[0]
        self.session.openWithCallback(
            lambda r: self.installPluginCallback(r, plugin, install_cmd) if r else None,
            MessageBox,
            f"{plugin_name}\n\nKurulsun mu?",
            MessageBox.TYPE_YESNO,
            default=False
        )
    
    def installPluginCallback(self, result, plugin, install_cmd):
        if result:
            plugin_name = plugin[0]
            self["status_label"].setText(f"Kuruluyor: {plugin_name}...")
            
            # Console ile kurulum
            self.session.openWithCallback(
                lambda r: self.installFinished(r, plugin),
                Console,
                title=f"{plugin_name} Kuruluyor",
                cmdlist=[install_cmd]
            )
    
    def installFinished(self, retval, plugin):
        plugin_name = plugin[0]
        logger.info(f"Installation finished for: {plugin_name}")
        
        # Dosyaya yaz
        self.write_plugin_to_file(plugin_name)
        
        # Listeyi yenile
        global INSTALLED_PLUGINS
        INSTALLED_PLUGINS = get_installed_plugins()
        self.buildList()
        self.refreshDescription()
        
        self["status_label"].setText(f"Kuruldu: {plugin_name}")
        
        # Restart sor
        self.session.openWithCallback(
            self.restartCallback,
            MessageBox,
            f"{plugin_name}\n\nKurulum tamamlandı.\n\nGUI yeniden başlatılsın mı?",
            MessageBox.TYPE_YESNO,
            default=True
        )
    
    def uninstallPlugin(self, plugin, uninstall_cmd):
        plugin_name = plugin[0]
        self.session.openWithCallback(
            lambda r: self.uninstallPluginCallback(r, plugin, uninstall_cmd) if r else None,
            MessageBox,
            f"{plugin_name}\n\nKaldırılsın mı?",
            MessageBox.TYPE_YESNO,
            default=False
        )
    
    def uninstallPluginCallback(self, result, plugin, uninstall_cmd):
        if result:
            plugin_name = plugin[0]
            self["status_label"].setText(f"Kaldırılıyor: {plugin_name}...")
            
            if uninstall_cmd and uninstall_cmd.strip():
                self.session.openWithCallback(
                    lambda r: self.uninstallFinished(r, plugin),
                    Console,
                    title=f"{plugin_name} Kaldırılıyor",
                    cmdlist=[uninstall_cmd]
                )
            else:
                self.uninstallFinished(None, plugin)
    
    def uninstallFinished(self, retval, plugin):
        plugin_name = plugin[0]
        logger.info(f"Uninstall finished for: {plugin_name}")
        
        # Listeden kaldır
        self.remove_from_installed_list(plugin_name)
        
        # Listeyi yenile
        global INSTALLED_PLUGINS
        INSTALLED_PLUGINS = get_installed_plugins()
        self.buildList()
        self.refreshDescription()
        
        self["status_label"].setText(f"Kaldırıldı: {plugin_name}")
    
    def write_plugin_to_file(self, plugin_name):
        try:
            plugin_dir = os.path.dirname(INSTALLED_PLUGINS_FILE)
            if not os.path.exists(plugin_dir):
                os.makedirs(plugin_dir, exist_ok=True)
            
            if not os.path.exists(INSTALLED_PLUGINS_FILE):
                with open(INSTALLED_PLUGINS_FILE, "w", encoding="utf-8") as f:
                    f.write("")
            
            existing = []
            try:
                with open(INSTALLED_PLUGINS_FILE, "r", encoding="utf-8") as f:
                    existing = [line.strip() for line in f if line.strip()]
            except:
                pass
            
            if plugin_name not in existing:
                with open(INSTALLED_PLUGINS_FILE, "a", encoding="utf-8") as f:
                    f.write(f"{plugin_name}\n")
                logger.info(f"Written '{plugin_name}' to installed plugins file")
        except Exception as e:
            logger.error(f"Error writing to file: {str(e)}")
    
    def remove_from_installed_list(self, plugin_name):
        try:
            if not os.path.exists(INSTALLED_PLUGINS_FILE):
                return
            
            with open(INSTALLED_PLUGINS_FILE, "r", encoding="utf-8") as f:
                lines = f.readlines()
            
            new_lines = [line for line in lines if line.strip() != plugin_name]
            
            with open(INSTALLED_PLUGINS_FILE, "w", encoding="utf-8") as f:
                for line in new_lines:
                    f.write(line)
            
            logger.info(f"Removed '{plugin_name}' from installed plugins file")
        except Exception as e:
            logger.error(f"Error removing from file: {str(e)}")
    
    def restartCallback(self, result):
        if result:
            self["status_label"].setText("GUI yeniden başlatılıyor...")
            from os import system
            system("init 4; sleep 3; init 3 &")
    
    def check_for_updates(self):
        try:
            if self.version_check_in_progress:
                return
            self.version_check_in_progress = True
            self["status_label"].setText("Güncellemeler kontrol ediliyor...")
            self.version_buffer = b''
            self.container.execute(f"wget -q -O - {VERSION_URL}")
        except Exception as e:
            self.version_check_in_progress = False
            self["status_label"].setText(f"Güncelleme kontrolü hatası: {str(e)}")
    
    def version_data_avail(self, data):
        self.version_buffer += data
    
    def command_finished(self, retval):
        if self.version_check_in_progress:
            self.version_check_closed(retval)
    
    def version_check_closed(self, retval):
        self.version_check_in_progress = False
        if retval == 0:
            try:
                remote_version = self.version_buffer.decode().strip()
                if remote_version != PLUGIN_VERSION:
                    self.session.openWithCallback(
                        self.start_update,
                        MessageBox,
                        f"Yeni sürüm mevcut: v{remote_version}\n\nGüncellensin mi?",
                        MessageBox.TYPE_YESNO
                    )
                else:
                    self["status_label"].setText("Plugin güncel")
            except:
                self["status_label"].setText("Güncelleme kontrolü başarısız")
        else:
            self["status_label"].setText("Güncelleme kontrolü başarısız")
    
    def start_update(self, answer):
        if answer:
            try:
                self["status_label"].setText("Güncelleniyor...")
                self.container.execute(UPDATE_COMMAND)
            except Exception as e:
                self["status_label"].setText(f"Güncelleme hatası: {str(e)}")
    
    def pageUp(self):
        """Yedek - handleLeft'e yönlendir"""
        self.handleLeft()
    
    def pageDown(self):
        """Yedek - handleRight'a yönlendir"""
        self.handleRight()
    
    def exit(self):
        self.close()
    
    def handleBlueKey(self):
        """Mavi tuş - kategori panelinde ayarlar, plugin panelinde resimler"""
        if self.active_panel == "categories":
            # Kategori panelindeyken ayarları aç
            self.openSettings()
        else:
            # Plugin panelindeyken resimleri aç
            self.openImageViewer()
    
    def openImageViewer(self):
        plugin = self.getCurrentPluginFull()
        if plugin and len(plugin) >= 5:
            plugin_name, icon_path, install_cmd, uninstall_cmd, desc_file = plugin[:5]
            image_urls = PICTURES_MAP.get(desc_file.lower(), [])
            if image_urls:
                self.session.open(ImageViewerScreen, image_urls, plugin_name)
            else:
                self["status_label"].setText(f"{plugin_name} icin resim bulunamadi")
    
    def installPlugin(self):
        plugin = self.getCurrentPluginFull()
        if plugin and len(plugin) >= 7:
            plugin_name, icon_path, install_cmd, uninstall_cmd, desc_file, category, package_name = plugin[:7]
            
            # DÜZELTME: Kurulu pluginleri kontrol etmeden önce listeyi güncelle
            global INSTALLED_PLUGINS
            INSTALLED_PLUGINS = get_installed_plugins()
            
            is_installed = plugin_name in INSTALLED_PLUGINS
            
            logger.info(f"installPlugin called for: {plugin_name}, is_installed: {is_installed}")
            logger.info(f"Current INSTALLED_PLUGINS: {INSTALLED_PLUGINS}")
            
            if is_installed:
                logger.info(f"Plugin is installed, calling uninstallPlugin for: {plugin_name}")
                self.uninstallPlugin(plugin, uninstall_cmd)
            else:
                logger.info(f"Plugin not installed, showing install confirmation for: {plugin_name}")
                self.showInstallConfirmation(plugin, install_cmd)
    
    def showInstallConfirmation(self, plugin, install_cmd):
        plugin_name = plugin[0]
        self.session.openWithCallback(
            lambda r: self.installPluginCallback(r, plugin, install_cmd) if r else None,
            MessageBox,
            f"{plugin_name}\n\nKurulsun mu?",
            MessageBox.TYPE_YESNO,
            default=False
        )
    
    def write_plugin_to_file(self, plugin_name):
        """Directly write plugin name to installed file"""
        import sys
        
        # Debug print to stderr
        print(f"DEBUG: write_plugin_to_file called with: {plugin_name}", file=sys.stderr)
        sys.stderr.flush()
        
        logger.info(f"write_plugin_to_file START - plugin: {plugin_name}")
        
        try:
            # Ensure directory exists
            plugin_dir = os.path.dirname(INSTALLED_PLUGINS_FILE)
            if not os.path.exists(plugin_dir):
                os.makedirs(plugin_dir, exist_ok=True)
                logger.info(f"Created directory: {plugin_dir}")
            
            # Ensure file exists
            if not os.path.exists(INSTALLED_PLUGINS_FILE):
                with open(INSTALLED_PLUGINS_FILE, "w", encoding="utf-8") as f:
                    f.write("")
                logger.info(f"Created file: {INSTALLED_PLUGINS_FILE}")
            
            # Read existing plugins
            existing = []
            try:
                with open(INSTALLED_PLUGINS_FILE, "r", encoding="utf-8") as f:
                    existing = [line.strip() for line in f if line.strip()]
            except Exception as e:
                logger.error(f"Error reading file: {e}")
            
            logger.info(f"Existing plugins: {existing}")
            
            # Write if not already exists
            if plugin_name not in existing:
                with open(INSTALLED_PLUGINS_FILE, "a", encoding="utf-8") as f:
                    f.write(f"{plugin_name}\n")
                logger.info(f"SUCCESS: Written '{plugin_name}' to installed plugins file")
                print(f"DEBUG: Successfully wrote {plugin_name} to file", file=sys.stderr)
            else:
                logger.info(f"Plugin '{plugin_name}' already exists in file")
            
            # Verify write immediately
            try:
                with open(INSTALLED_PLUGINS_FILE, "r", encoding="utf-8") as f:
                    content = f.read()
                logger.info(f"File content after write: {repr(content)}")
                print(f"DEBUG: File content: {repr(content)}", file=sys.stderr)
            except Exception as e:
                logger.error(f"Error verifying file: {e}")
                
        except Exception as e:
            logger.error(f"Error in write_plugin_to_file: {str(e)}")
            print(f"DEBUG: Error in write_plugin_to_file: {str(e)}", file=sys.stderr)
            # Try fallback method
            try:
                import subprocess
                result = subprocess.run(f"echo '{plugin_name}' >> {INSTALLED_PLUGINS_FILE}", shell=True, capture_output=True, text=True)
                logger.info(f"Fallback: Wrote '{plugin_name}' using shell command, result: {result.returncode}")
                print(f"DEBUG: Fallback shell command result: {result.returncode}", file=sys.stderr)
            except Exception as e2:
                logger.error(f"Fallback also failed: {e2}")
    
    def uninstallPlugin(self, plugin, uninstall_cmd):
        plugin_name = plugin[0]
        package_name = plugin[6] if len(plugin) >= 7 else plugin_name.lower().replace(" ", "-")
        
        # Clean package name - remove extra spaces
        package_name = package_name.strip()
        
        # Also extract search terms from plugin name for better matching
        # For example: "DostTV Canlı" -> search for "dost", "tv", "canli"
        search_terms = []
        for word in plugin_name.lower().split():
            # Remove special chars and get significant parts
            clean_word = word.replace("ı", "i").replace("ğ", "g").replace("ü", "u").replace("ş", "s").replace("ö", "o").replace("ç", "c")
            if len(clean_word) >= 3:  # Only use words 3+ chars
                search_terms.append(clean_word)
        
        logger.info(f"uninstallPlugin - plugin_name: {plugin_name}")
        logger.info(f"uninstallPlugin - package_name: {package_name}")
        logger.info(f"uninstallPlugin - search_terms: {search_terms}")
        logger.info(f"uninstallPlugin - uninstall_cmd: {uninstall_cmd}")
        
        if not uninstall_cmd or uninstall_cmd.strip() == "":
            logger.warning(f"No uninstall command for {plugin_name}, will only clean system files")
            self.session.openWithCallback(
                lambda r: self.directCleanup(plugin_name, package_name) if r else None,
                MessageBox,
                f"{plugin_name}\n\nBu eklenti icin kaldirma komutu mevcut degil.\nSistem dosyalari temizlenecek.\n\nDevam edilsin mi?",
                MessageBox.TYPE_YESNO,
                default=False
            )
            return
        
        self.session.openWithCallback(
            lambda r: self.uninstallPluginCallback(r, plugin, uninstall_cmd, package_name) if r else None,
            MessageBox,
            f">>> {plugin_name} <<<\n\nEklentiyi kaldirmak istediginize emin misiniz?\n\nBu islem geri alinamaz!",
            MessageBox.TYPE_YESNO,
            default=False
        )
    
    def uninstallPluginCallback(self, result, plugin, uninstall_cmd, package_name):
        if result:
            plugin_name = plugin[0]
            self["status_label"].setText(f"Kaldiriliyor: {plugin_name}...")
            logger.info(f"User confirmed uninstall for: {plugin_name}")
            
            # Use the new safe removal function
            # plugin[6] is the package slug
            plugin_slug = plugin[6] if len(plugin) >= 7 else package_name
            
            success = self.remove_plugin_real(
                plugin_name=plugin_name,
                uninstall_cmd=uninstall_cmd,
                plugin_slug=plugin_slug
            )
            
            if success:
                self["status_label"].setText(f"Basariyla kaldirildi: {plugin_name}")
            else:
                self["status_label"].setText(f"Kaldirma basarisiz: {plugin_name}")
        else:
            logger.info("User cancelled uninstall")
    
    def directCleanup(self, plugin_name, package_name):
        """Direct cleanup without uninstall script"""
        logger.info(f"Direct cleanup (no uninstall script) for: {plugin_name}")
        self["status_label"].setText(f"Temizleniyor: {plugin_name}...")
        
        # Use the safe removal function with no uninstall command
        success = self.remove_plugin_real(
            plugin_name=plugin_name,
            uninstall_cmd="",  # No uninstall command
            plugin_slug=package_name
        )
        
        if success:
            self["status_label"].setText(f"Basariyla temizlendi: {plugin_name}")
        else:
            self["status_label"].setText(f"Temizleme basarisiz: {plugin_name}")
    
    def uninstallFinishedWrapper(self, retval=None):
        """Wrapper for uninstall callback to capture plugin info"""
        plugin = getattr(self, 'current_uninstall_plugin', None)
        package_name = getattr(self, 'current_uninstall_package', None)
        
        logger.info(f"uninstallFinishedWrapper called with retval={retval}")
        
        # Clear stored values
        self.current_uninstall_plugin = None
        self.current_uninstall_package = None
        
        if plugin:
            self.uninstallFinished(retval, plugin, package_name)
        else:
            logger.warning("No plugin info found in uninstallFinishedWrapper")
    
    def uninstallFinished(self, retval, plugin, package_name):
        plugin_name = plugin[0]
        logger.info(f"Uninstall script finished for: {plugin_name} with return code: {retval}")
        
        # Log current plugin directories BEFORE cleanup
        logger.info("=" * 50)
        logger.info("PLUGIN DIRECTORIES BEFORE CLEANUP:")
        try:
            import subprocess
            result = subprocess.run(
                "ls -la /usr/lib/enigma2/python/Plugins/Extensions/ 2>/dev/null",
                shell=True, capture_output=True, text=True
            )
            logger.info(result.stdout)
        except:
            pass
        logger.info("=" * 50)
        
        # Now clean up plugin files from system
        logger.info(f"Cleaning up plugin files for: {package_name}")
        files_deleted = self.clean_plugin_files(package_name)
        logger.info(f"Deleted {files_deleted} files/directories for {package_name}")
        
        # Log current plugin directories AFTER cleanup
        logger.info("=" * 50)
        logger.info("PLUGIN DIRECTORIES AFTER CLEANUP:")
        try:
            import subprocess
            result = subprocess.run(
                "ls -la /usr/lib/enigma2/python/Plugins/Extensions/ 2>/dev/null",
                shell=True, capture_output=True, text=True
            )
            logger.info(result.stdout)
        except:
            pass
        logger.info("=" * 50)
        
        # Remove from installed list
        self.remove_installed_plugin(plugin_name)
        
        # Clean cached .pyo files
        self.clean_pyc_files()
        
        # Clean Enigma2 plugin cache
        self.clean_enigma_plugin_cache()
        
        # Immediately refresh the list
        global INSTALLED_PLUGINS
        INSTALLED_PLUGINS = get_installed_plugins()
        logger.info(f"INSTALLED_PLUGINS after uninstall: {INSTALLED_PLUGINS}")
        
        self.buildList()
        self.refreshDescription()
        
        logger.info(f"Uninstallation finished for: {plugin_name}")
        
        self["status_label"].setText(f"Kaldirma tamamlandi: {plugin_name}")
        
        self.restart_timer = eTimer()
        self.restart_timer.callback.append(lambda: self.showUninstallComplete(plugin_name))
        self.restart_timer.start(1500, True)
    
    def clean_plugin_files(self, package_name):
        """Search and delete plugin files from system - COMPREHENSIVE VERSION"""
        import glob
        
        logger.info("=" * 50)
        logger.info(f"CLEANING PLUGIN FILES FOR: {package_name}")
        logger.info("=" * 50)
        
        files_deleted = 0
        dirs_deleted = 0
        
        # First, try to find the ACTUAL plugin directory name
        actual_dirs = []
        search_bases = [
            "/usr/lib/enigma2/python/Plugins/Extensions/",
            "/usr/lib/enigma2/python/Plugins/SystemPlugins/"
        ]
        
        # Search with variations of package name
        package_variations = [
            package_name,
            package_name.replace("-", ""),
            package_name.replace(" ", ""),
            package_name.replace("-", "_"),
            package_name.title(),
            package_name.upper(),
            package_name.lower()
        ]
        
        logger.info(f"Searching for variations: {package_variations}")
        
        for base in search_bases:
            if os.path.exists(base):
                try:
                    for item in os.listdir(base):
                        item_lower = item.lower()
                        for variant in package_variations:
                            if variant.lower() in item_lower:
                                full_path = os.path.join(base, item)
                                if full_path not in actual_dirs:
                                    actual_dirs.append(full_path)
                                    logger.info(f"Found actual plugin dir: {full_path}")
                except Exception as e:
                    logger.error(f"Error listing {base}: {e}")
        
        # Delete found directories
        for dir_path in actual_dirs:
            try:
                if os.path.isdir(dir_path):
                    logger.info(f"Deleting plugin directory: {dir_path}")
                    shutil.rmtree(dir_path)
                    dirs_deleted += 1
                    logger.info(f"✓ Successfully deleted: {dir_path}")
                elif os.path.isfile(dir_path):
                    os.remove(dir_path)
                    files_deleted += 1
                    logger.info(f"✓ Successfully deleted file: {dir_path}")
            except Exception as e:
                logger.error(f"✗ Error deleting {dir_path}: {e}")
        
        # Also search with glob patterns
        search_patterns = [
            f"/usr/lib/enigma2/python/Plugins/Extensions/*{package_name}*",
            f"/usr/lib/enigma2/python/Plugins/SystemPlugins/*{package_name}*",
            f"/usr/share/enigma2/{package_name}*",
            f"/etc/enigma2/{package_name}*",
        ]
        
        for pattern in search_patterns:
            try:
                matches = glob.glob(pattern, recursive=False)
                for filepath in matches:
                    if filepath not in actual_dirs:  # Don't delete twice
                        try:
                            if os.path.isfile(filepath):
                                os.remove(filepath)
                                logger.info(f"✓ Deleted file: {filepath}")
                                files_deleted += 1
                            elif os.path.isdir(filepath):
                                shutil.rmtree(filepath)
                                logger.info(f"✓ Deleted directory: {filepath}")
                                dirs_deleted += 1
                        except Exception as e:
                            logger.error(f"✗ Error deleting {filepath}: {e}")
            except Exception as e:
                logger.error(f"Error searching pattern {pattern}: {e}")
        
        # Additional find command search
        try:
            import subprocess
            logger.info(f"Running find command for: {package_name}")
            
            # Search in plugin directories
            result = subprocess.run(
                f"find /usr/lib/enigma2/python/Plugins -iname '*{package_name}*' 2>/dev/null",
                shell=True, capture_output=True, text=True
            )
            
            if result.returncode == 0 and result.stdout.strip():
                logger.info(f"Find command results:\n{result.stdout}")
                for filepath in result.stdout.strip().split('\n'):
                    if filepath and os.path.exists(filepath):
                        try:
                            if os.path.isfile(filepath):
                                os.remove(filepath)
                                logger.info(f"✓ Deleted (find): {filepath}")
                                files_deleted += 1
                            elif os.path.isdir(filepath):
                                shutil.rmtree(filepath)
                                logger.info(f"✓ Deleted dir (find): {filepath}")
                                dirs_deleted += 1
                        except Exception as e:
                            logger.error(f"✗ Error deleting {filepath}: {e}")
        except Exception as e:
            logger.error(f"Error in find command: {e}")
        
        total_deleted = files_deleted + dirs_deleted
        logger.info("=" * 50)
        logger.info(f"CLEANUP SUMMARY:")
        logger.info(f"  Directories deleted: {dirs_deleted}")
        logger.info(f"  Files deleted: {files_deleted}")
        logger.info(f"  TOTAL: {total_deleted}")
        logger.info("=" * 50)
        
        return total_deleted
    
    def clean_pyc_files(self):
        """Clean up cached .pyc and .pyo files"""
        try:
            import subprocess
            # Clean .pyo files older than 1 day
            subprocess.run(
                "find /usr/lib/enigma2/python -name '*.pyo' -mtime +1 -delete 2>/dev/null",
                shell=True
            )
            logger.info("Cleaned up .pyo files")
        except Exception as e:
            logger.error(f"Error cleaning .pyo files: {e}")
    
    def clean_enigma_plugin_cache(self):
        """Clean Enigma2 plugin cache files - AGGRESSIVE VERSION"""
        try:
            import subprocess
            logger.info("Cleaning Enigma2 plugin cache files...")
            
            # Remove ALL .pyc and .pyo files from plugin directories
            cache_commands = [
                "find /usr/lib/enigma2/python/Plugins -name '*.pyc' -delete 2>/dev/null",
                "find /usr/lib/enigma2/python/Plugins -name '*.pyo' -delete 2>/dev/null",
                "find /usr/lib/enigma2/python/Components -name '*.pyc' -delete 2>/dev/null",
                "find /usr/lib/enigma2/python/Components -name '*.pyo' -delete 2>/dev/null",
            ]
            
            for cmd in cache_commands:
                result = subprocess.run(cmd, shell=True, capture_output=True, text=True)
                logger.info(f"Executed: {cmd}")
            
            # Also remove any __pycache__ directories
            subprocess.run(
                "find /usr/lib/enigma2/python/Plugins -type d -name '__pycache__' -exec rm -rf {} + 2>/dev/null",
                shell=True
            )
            
            logger.info("✓ Cleaned Enigma2 plugin cache files")
        except Exception as e:
            logger.error(f"Error cleaning Enigma2 cache: {e}")
    
    def installPluginCallback(self, result, plugin, install_cmd):
        if result:
            plugin_name = plugin[0]
            self.installing_plugin_name = plugin_name
            
            # Immediately write to file
            logger.info(f"User confirmed installation, writing '{plugin_name}' to file...")
            self.write_plugin_to_file(plugin_name)
            
            # Progress dialog aç
            self.progress_dialog = self.session.open(
                DownloadProgressScreen,
                plugin_name
            )
            
            self["status_label"].setText(f"Kuruluyor: {plugin_name}...")
            
            # Arka planda komut çalıştır - Console ekranı GÖSTERME
            logger.info(f"Running command: {install_cmd}")
            self.install_container = eConsoleAppContainer()
            self.install_container.appClosed.append(self.installFinished_background)
            self.install_container.execute(install_cmd)
    
    def installFinished_background(self, retval=None):
        """Arka plan kurulum bittiğinde çağrılır"""
        logger.info(f"Background install finished, retval: {retval}")
        # Progress dialog'u HEMEN kapatma - restart dialog'dan sonra kapat
        # Normal installFinished'ı çağır
        self.installFinished(retval)
    
    
    def _closeProgressDialog(self):
        """Progress dialog'u kapat"""
        try:
            if hasattr(self, 'progress_dialog') and self.progress_dialog:
                self.progress_dialog.close(True)
                self.progress_dialog = None
                logger.info("Progress dialog closed")
        except Exception as e:
            logger.error(f"Error closing progress dialog: {e}")
    
    def installFinished(self, retval=None):
        logger.info("=" * 50)
        logger.info(f"INSTALL FINISHED - Return value: {retval}")
        
        plugin = self.getCurrentPluginFull()
        plugin_name = getattr(self, 'installing_plugin_name', None)
        
        logger.info(f"installing_plugin_name: {plugin_name}")
        logger.info(f"getCurrentPluginFull: {plugin[0] if plugin else None}")
        
        if not plugin_name and plugin:
            plugin_name = plugin[0]
        
        logger.info(f"Final plugin name: {plugin_name}")
        
        if plugin_name:
            self["status_label"].setText(f"Kurulum tamamlandi: {plugin_name}")
            logger.info(f"Installation finished for: {plugin_name}")
            
            # Backup write to file
            logger.info(f"Backup write for: {plugin_name}")
            self.write_plugin_to_file(plugin_name)
            self.log_installed_plugin(plugin_name)
            
            # Listeyi hemen güncelle
            global INSTALLED_PLUGINS
            INSTALLED_PLUGINS = get_installed_plugins()
            logger.info(f"INSTALLED_PLUGINS updated: {INSTALLED_PLUGINS}")
            
            self.buildList()
            self.refreshDescription()
            
            # ÖNCE progress dialog'u güncelle ve kapat, SONRA restart dialog göster
            logger.info("Updating and closing progress dialog...")
            if hasattr(self, 'progress_dialog') and self.progress_dialog:
                try:
                    # Success mesajı göster
                    self.progress_dialog["status"].setText("✓ Kurulum Başarılı!")
                    self.progress_dialog["progress"].setValue(100)
                    # 1 saniye göster sonra kapat
                    self.progress_close_timer = eTimer()
                    self.progress_close_timer.callback.append(self._closeProgressDialog)
                    self.progress_close_timer.start(1000, True)
                except Exception as e:
                    logger.error(f"Error updating progress: {e}")
                    self._closeProgressDialog()
            
            # Restart dialog için timer (progress kapandıktan sonra)
            logger.info("Setting up restart dialog...")
            self.restart_timer = eTimer()
            self.restart_timer.callback.append(lambda *args: self.showInstallRestartDialog(plugin_name))
            self.restart_timer.start(1500, True)  # 1.5 saniye gecikme
            logger.info("Restart dialog timer set for 1.5 seconds")
        else:
            logger.warning("No plugin name found!")
        
        self.installing_plugin_name = None
        logger.info("=" * 50)
    
    def showUninstallComplete(self, plugin_name):
        logger.info("=" * 50)
        logger.info(f"SHOWING UNINSTALL COMPLETE FOR: {plugin_name}")
        logger.info("Opening MessageBox for restart confirmation...")
        logger.info("=" * 50)
        
        try:
            self.session.openWithCallback(
                self.restartCallback,
                MessageBox,
                f">>> {plugin_name} KALDIRILDI <<<\n\nEklenti basariyla kaldirildi.\n\nGUI yeniden baslatilsin mi?\n\n(EVET = Yeniden Baslat / HAYIR = Iptal)",
                MessageBox.TYPE_YESNO,
                timeout=0,
                default=True
            )
            logger.info("MessageBox successfully opened for uninstall restart")
        except Exception as e:
            logger.error(f"ERROR opening MessageBox: {str(e)}")
            self["status_label"].setText(f"Hata: {str(e)}")
        
        self.refreshInstalledStatus()
    
    def refreshInstalledStatus(self):
        global INSTALLED_PLUGINS
        INSTALLED_PLUGINS = get_installed_plugins()
        self.buildList()
        self.refreshDescription()
    
    def askForRestart(self, plugin_name):
        logger.info("=" * 50)
        logger.info(f"ASKING FOR GUI RESTART: {plugin_name}")
        logger.info("Opening MessageBox now...")
        logger.info("=" * 50)
        
        try:
            self.session.openWithCallback(
                self.restartCallback,
                MessageBox,
                f"{plugin_name}\n\n✓ KURULDU\n\n" +
                f"Plugin başarıyla kuruldu.\n\n" +
                f"━━━━━━━━━━━━━━━━━━━━━━━\n\n" +
                f"Değişikliklerin geçerli olması için\n" +
                f"GUI yeniden başlatılmalı.\n\n" +
                f"Şimdi yeniden başlatılsın mı?",
                MessageBox.TYPE_YESNO,
                timeout=0,
                default=False  # Don't auto-select YES
            )
            logger.info("MessageBox successfully opened")
        except Exception as e:
            logger.error(f"ERROR opening MessageBox: {str(e)}")
            self["status_label"].setText(f"Hata: {str(e)}")
    
    def showInstallRestartDialog(self, plugin_name):
        """Show restart dialog after installation (called with delay to avoid Console overlap)"""
        logger.info("=" * 50)
        logger.info(f"SHOWING INSTALL RESTART DIALOG: {plugin_name}")
        logger.info("=" * 50)
        
        # Update status to show we're about to ask
        self["status_label"].setText(f"Kurulum tamamlandi - Soru soruluyor...")
        
        try:
            logger.info("Opening MessageBox with TYPE_YESNO, timeout=0, default=False")
            self.session.openWithCallback(
                self.restartCallback,
                MessageBox,
                f"{plugin_name}\n\n✓ KURULDU\n\n" +
                f"Plugin başarıyla kuruldu.\n\n" +
                f"━━━━━━━━━━━━━━━━━━━━━━━\n\n" +
                f"Değişikliklerin geçerli olması için\n" +
                f"GUI yeniden başlatılmalı.\n\n" +
                f"Şimdi yeniden başlatılsın mı?",
                MessageBox.TYPE_YESNO,
                timeout=0,
                default=False
            )
            logger.info("Install restart MessageBox successfully opened")
            logger.info("Waiting for user response...")
        except Exception as e:
            logger.error(f"ERROR opening install restart MessageBox: {str(e)}")
            logger.error(f"Exception details: {type(e).__name__}: {str(e)}")
            import traceback
            logger.error(f"Traceback: {traceback.format_exc()}")
            self["status_label"].setText(f"Kurulum tamamlandi: {plugin_name}")
    
    def consoleFinished(self):
        pass
    
    def restartCallback(self, result):
        logger.info(f"GUI Restart callback received with result: {result}")
        if result:
            logger.info("User confirmed GUI restart - restarting Enigma2 GUI")
            self["status_label"].setText("GUI yeniden baslatiliyor...")
            
            # Restart GUI without showing terminal/console
            from os import system
            from enigma import eTimer
            
            # Small delay then restart
            self.restart_gui_timer = eTimer()
            self.restart_gui_timer.callback.append(self.executeGuiRestart)
            self.restart_gui_timer.start(500, True)  # 0.5 second delay
        else:
            logger.info("User declined GUI restart - staying in GUI")
            self["status_label"].setText("Yeniden baslatma iptal edildi")
    
    def executeGuiRestart(self):
        """Execute GUI restart - SETSID METHOD (complete detachment)"""
        logger.info("Executing GUI restart (setsid method for complete detachment)...")
        from os import system
        
        # Use setsid to completely detach from parent session
        # This ensures the process continues even after Enigma2 dies
        # Sequence: init 4 (stop) -> sleep 3 (wait) -> init 3 (start)
        system("setsid sh -c 'init 4; sleep 3; init 3' >/dev/null 2>&1 &")
        logger.info("Restart command sent with setsid: init 4; sleep 3; init 3")
    
    def log_installed_plugin(self, plugin_name):
        try:
            plugin_dir = os.path.dirname(INSTALLED_PLUGINS_FILE)
            if not os.path.exists(plugin_dir):
                os.makedirs(plugin_dir, exist_ok=True)
            
            # Dosyanın var olduğundan emin ol
            if not os.path.exists(INSTALLED_PLUGINS_FILE):
                with open(INSTALLED_PLUGINS_FILE, "w", encoding="utf-8") as f:
                    f.write("")
            
            existing_plugins = set()
            try:
                with open(INSTALLED_PLUGINS_FILE, "r", encoding="utf-8") as f:
                    for line in f:
                        plugin = line.strip()
                        if plugin:
                            existing_plugins.add(plugin)
            except:
                pass
            
            if plugin_name not in existing_plugins:
                with open(INSTALLED_PLUGINS_FILE, "a", encoding="utf-8") as f:
                    f.write(f"{plugin_name}\n")
                logger.info(f"Plugin logged to installed list: {plugin_name}")
            else:
                logger.info(f"Plugin already in installed list: {plugin_name}")
        except Exception as e:
            logger.error(f"Error logging plugin: {str(e)}")
    
    def remove_from_installed_list(self, plugin_name):
        """Remove plugin from installed list file"""
        try:
            if not os.path.exists(INSTALLED_PLUGINS_FILE):
                return

            with open(INSTALLED_PLUGINS_FILE, "r", encoding="utf-8") as f:
                lines = f.readlines()

            with open(INSTALLED_PLUGINS_FILE, "w", encoding="utf-8") as f:
                for line in lines:
                    if line.strip() != plugin_name:
                        f.write(line)

            logger.info(f"Removed from installed list: {plugin_name}")
        except Exception as e:
            logger.error(f"installed_plugins.txt yazma hatası: {e}")
    
    def remove_plugin_real(self, plugin_name, uninstall_cmd, plugin_slug):
        """
        SAFE AND PROPER PLUGIN REMOVAL
        1. Run uninstall.sh if exists
        2. Force delete plugin folders
        3. Remove via opkg if installed
        4. Only remove from list if successful
        5. Give clear error messages to user
        """
        logger.info("=" * 60)
        logger.info(f"REMOVING PLUGIN: {plugin_name}")
        logger.info(f"Uninstall command: {uninstall_cmd}")
        logger.info(f"Plugin slug: {plugin_slug}")
        logger.info("=" * 60)

        errors = []

        # 1. RUN uninstall.sh IF EXISTS
        if uninstall_cmd and uninstall_cmd.strip():
            try:
                logger.info("STEP 1: Running uninstall script...")
                ret = os.system(uninstall_cmd)
                if ret != 0:
                    errors.append(f"uninstall.sh çalıştı ama hata döndürdü (kod: {ret})")
                    logger.warning(f"uninstall.sh returned non-zero: {ret}")
                else:
                    logger.info("✓ uninstall.sh completed successfully")
            except Exception as e:
                errors.append(f"uninstall.sh çalıştırılamadı: {e}")
                logger.error(f"✗ uninstall.sh execution error: {e}")
        else:
            logger.info("STEP 1: No uninstall command, skipping...")

        # 2. FIND AND DELETE PLUGIN DIRECTORIES
        logger.info("STEP 2: Finding and deleting plugin directories...")
        
        # Generate possible plugin directory names
        slug_variations = [
            plugin_slug,
            plugin_slug.replace("-", ""),
            plugin_slug.replace("_", ""),
            plugin_slug.title(),
            plugin_slug.upper(),
            plugin_slug.lower(),
        ]
        
        # Also extract from plugin name
        name_parts = plugin_name.lower().replace(" ", "").replace("-", "")
        if name_parts not in slug_variations:
            slug_variations.append(name_parts)
        
        logger.info(f"Searching for variations: {slug_variations}")
        
        possible_paths = []
        search_bases = [
            "/usr/lib/enigma2/python/Plugins/Extensions/",
            "/usr/lib/enigma2/python/Plugins/SystemPlugins/",
        ]
        
        # Find actual directories
        for base in search_bases:
            if os.path.exists(base):
                try:
                    for item in os.listdir(base):
                        item_lower = item.lower()
                        for variant in slug_variations:
                            if variant.lower() in item_lower or item_lower in variant.lower():
                                full_path = os.path.join(base, item)
                                if full_path not in possible_paths:
                                    possible_paths.append(full_path)
                                    logger.info(f"Found plugin path: {full_path}")
                except Exception as e:
                    logger.error(f"Error listing {base}: {e}")
        
        # Delete found directories
        deleted_count = 0
        for path in possible_paths:
            if os.path.exists(path):
                try:
                    if os.path.isdir(path):
                        shutil.rmtree(path)
                        logger.info(f"✓ Deleted folder: {path}")
                        deleted_count += 1
                    elif os.path.isfile(path):
                        os.remove(path)
                        logger.info(f"✓ Deleted file: {path}")
                        deleted_count += 1
                except Exception as e:
                    errors.append(f"Klasör silinemedi: {path} ({e})")
                    logger.error(f"✗ Error deleting {path}: {e}")
        
        if deleted_count > 0:
            logger.info(f"✓ Deleted {deleted_count} items")
        else:
            logger.warning("No plugin directories found to delete")

        # 3. CHECK AND REMOVE VIA OPKG
        logger.info("STEP 3: Checking opkg packages...")
        try:
            # Check for multiple possible package names
            package_names = [
                plugin_slug,
                f"enigma2-plugin-extensions-{plugin_slug}",
                f"enigma2-plugin-systemplugins-{plugin_slug}",
            ]
            
            removed_packages = []
            for pkg_name in package_names:
                try:
                    opkg_check = os.popen(f"opkg list-installed | grep -i {pkg_name}").read()
                    if opkg_check.strip():
                        logger.info(f"Found opkg package: {pkg_name}")
                        ret = os.system(f"opkg remove {pkg_name} --force-depends 2>&1")
                        if ret == 0:
                            logger.info(f"✓ opkg remove successful: {pkg_name}")
                            removed_packages.append(pkg_name)
                        else:
                            logger.warning(f"opkg remove returned: {ret} for {pkg_name}")
                except Exception as e:
                    logger.error(f"opkg check error for {pkg_name}: {e}")
            
            if removed_packages:
                logger.info(f"✓ Removed opkg packages: {removed_packages}")
            else:
                logger.info("No opkg packages found")
                
        except Exception as e:
            errors.append(f"opkg kontrolü/kaldırma hatası: {e}")
            logger.error(f"✗ opkg process error: {e}")

        # 4. CLEAN CACHE FILES
        logger.info("STEP 4: Cleaning cache files...")
        try:
            cache_patterns = [
                f"find /usr/lib/enigma2/python/Plugins -name '*{plugin_slug}*.pyc' -delete 2>/dev/null",
                f"find /usr/lib/enigma2/python/Plugins -name '*{plugin_slug}*.pyo' -delete 2>/dev/null",
            ]
            for cmd in cache_patterns:
                os.system(cmd)
            logger.info("✓ Cache files cleaned")
        except Exception as e:
            logger.warning(f"Cache cleanup warning: {e}")

        # 5. FINAL CHECK - STILL EXISTS?
        logger.info("STEP 5: Final verification...")
        still_exists = False
        remaining_paths = []
        
        for path in possible_paths:
            if os.path.exists(path):
                still_exists = True
                remaining_paths.append(path)
                logger.error(f"✗ Still exists: {path}")
        
        if still_exists:
            errors.append(f"Plugin dosyaları hâlâ sistemde: {', '.join(remaining_paths)}")

        # 6. RESULT
        logger.info("=" * 60)
        if errors:
            error_msg = "\n".join(errors)
            logger.error(f"PLUGIN REMOVAL FAILED:\n{error_msg}")
            logger.info("=" * 60)
            
            self.session.open(
                MessageBox,
                f"{plugin_name}\n\n✗ SİLİNEMEDİ!\n\n" +
                f"━━━━━━━━━━━━━━━━━━━━━━━\n\n" +
                f"HATALAR:\n\n" + error_msg + 
                f"\n\n━━━━━━━━━━━━━━━━━━━━━━━\n\n" +
                f"Lütfen GUI'yi yeniden başlatıp\ntekrar deneyin veya manuel kontrol edin.",
                MessageBox.TYPE_ERROR,
                timeout=0
            )
            return False
        else:
            # SUCCESS - Only now remove from list
            logger.info("PLUGIN REMOVAL SUCCESSFUL!")
            logger.info("=" * 60)
            
            self.remove_from_installed_list(plugin_name)
            
            # Refresh the plugin list
            global INSTALLED_PLUGINS
            INSTALLED_PLUGINS = get_installed_plugins()
            self.buildList()
            self.refreshDescription()
            
            # Show success message with restart question
            self.session.openWithCallback(
                self.restartCallback,
                MessageBox,
                f"{plugin_name}\n\n✓ SİSTEMDEN KALDIRILDI\n\n" +
                f"Plugin tamamen silindi.\n\n" +
                f"━━━━━━━━━━━━━━━━━━━━━━━\n\n" +
                f"Değişikliklerin geçerli olması için\n" +
                f"GUI yeniden başlatılmalı.\n\n" +
                f"Şimdi yeniden başlatılsın mı?",
                MessageBox.TYPE_YESNO,
                timeout=0,
                default=False  # Don't auto-select YES
            )
            return True
    
    def check_for_updates(self):
        try:
            if self.version_check_in_progress:
                return
            self.version_check_in_progress = True
            self["status_label"].setText("Gunellemeler kontrol ediliyor...")
            self.version_buffer = b''
            self.container.execute(f"wget -q -O - {VERSION_URL}")
        except Exception as e:
            self.version_check_in_progress = False
            self["status_label"].setText(f"Guncelleme kontrolu hatasi: {str(e)}")
    
    def version_data_avail(self, data):
        self.version_buffer += data
    
    def command_finished(self, retval):
        if self.version_check_in_progress:
            self.version_check_closed(retval)
    
    def version_check_closed(self, retval):
        self.version_check_in_progress = False
        if retval == 0:
            try:
                remote_version = self.version_buffer.decode().strip()
                if remote_version != PLUGIN_VERSION:
                    self.session.openWithCallback(
                        self.start_update,
                        MessageBox,
                        f"Yeni surum mevcut: v{remote_version}\n\nGuncellensin mi?",
                        MessageBox.TYPE_YESNO
                    )
                else:
                    self["status_label"].setText("Plugin guncel")
            except Exception as e:
                self["status_label"].setText("Guncelleme kontrolu basarisiz")
        else:
            self["status_label"].setText("Guncelleme kontrolu basarisiz")
    
    def start_update(self, answer):
        if answer:
            try:
                self["status_label"].setText("Yedekleniyor...")
                if os.path.exists(INSTALLED_PLUGINS_FILE):
                    shutil.copy2(INSTALLED_PLUGINS_FILE, BACKUP_PLUGINS_FILE)
                self["status_label"].setText("Guncelleniyor...")
                self.container.execute(UPDATE_COMMAND)
            except Exception as e:
                self["status_label"].setText(f"Yedekleme hatasi: {str(e)}")
    
    def handleLeft(self):
        """Sayfa atla - 8 geri"""
        try:
            if self.active_panel == "categories":
                catlist = self.getList()
                if catlist:
                    current = catlist.getSelectedIndex()
                    catlist.moveToIndex(max(0, current - 8))
            else:
                pluginlist = self.getPluginList()
                if pluginlist:
                    current = pluginlist.getSelectedIndex()
                    pluginlist.moveToIndex(max(0, current - 8))
        except Exception:
            pass
    
    def handleRight(self):
        """Sayfa atla - 8 ileri"""
        try:
            if self.active_panel == "categories":
                catlist = self.getList()
                if catlist:
                    current = catlist.getSelectedIndex()
                    max_index = len(catlist.list) - 1
                    catlist.moveToIndex(min(max_index, current + 8))
            else:
                pluginlist = self.getPluginList()
                if pluginlist:
                    current = pluginlist.getSelectedIndex()
                    max_index = len(pluginlist.list) - 1
                    pluginlist.moveToIndex(min(max_index, current + 8))
        except Exception:
            pass
    
    def handleUp(self):
        """Tek tek geri"""
        try:
            if self.active_panel == "categories":
                catlist = self.getList()
                if catlist:
                    current = catlist.getSelectedIndex()
                    catlist.moveToIndex(max(0, current - 1))
            else:
                pluginlist = self.getPluginList()
                if pluginlist:
                    current = pluginlist.getSelectedIndex()
                    pluginlist.moveToIndex(max(0, current - 1))
        except Exception:
            pass
    
    def handleDown(self):
        """Tek tek ileri"""
        try:
            if self.active_panel == "categories":
                catlist = self.getList()
                if catlist:
                    current = catlist.getSelectedIndex()
                    max_index = len(catlist.list) - 1
                    catlist.moveToIndex(min(max_index, current + 1))
            else:
                pluginlist = self.getPluginList()
                if pluginlist:
                    current = pluginlist.getSelectedIndex()
                    max_index = len(pluginlist.list) - 1
                    pluginlist.moveToIndex(min(max_index, current + 1))
        except Exception:
            pass
    
    def pageUp(self):
        """Yedek - tek tek geri"""
        self.handleUp()
    
    def pageDown(self):
        """Yedek - tek tek ileri"""
        self.handleDown()
    
    def handleOk(self):
        if self.active_panel == "categories":
            # Kategori secildi, plugin paneline git
            try:
                current = self["catlist"].getCurrent()
                if current and len(current) > 0:
                    cat_id = current[0][0]
                    # ÖNCE panel değiştir ki buildList selection=True ile çalışsın
                    self.active_panel = "plugins"
                    # Panel indicator'ı güncelle
                    self["panel_indicator"].setText("► PLUGİN PANELİ")
                    # Mavi tuş etiketini resimlere çevir
                    self["key_blue"].setText("📷 RESİMLER")
                    # Kategoriyi filtrele (buildList içinde selection kontrol edilecek)
                    self.categorySelected(cat_id)
                    # UI güncellemelerini yap
                    self["pluginlist"].moveToIndex(0)
                    self.refreshDescription()
                    self["status_label"].setText("► Plugin - OK:Kur/Kaldır 📷:Resimler EXIT:Geri")
                    # Plugin list style'ı güncelle
                    self.updatePluginListStyle()
            except Exception as e:
                logger.debug(f"handleOk category error: {str(e)}")
        else:
            # Plugin panelinde OK -> Kur/Kaldir
            self.installPlugin()
    
    def goBack(self):
        """EXIT/RED tuşu ile geri dön veya çık"""
        if self.active_panel == "plugins":
            # Plugin panelinden kategori paneline geri dön
            
            # Flag set et - onCategoryChanged çalışmasın
            self.in_go_back = True
            
            try:
                # ÖNCE active_panel'i değiştir
                self.active_panel = "categories"
                
                # Panel indicator'ı güncelle
                self["panel_indicator"].setText("► KATEGORİ PANELİ")
                
                # Son seçili kategori index'ini al
                if hasattr(self, 'last_category_index') and self.last_category_index is not None:
                    last_idx = self.last_category_index
                else:
                    last_idx = 0
                
                # Kategori listesinde pozisyona git
                catlist = self.getList()
                if catlist:
                    catlist.moveToIndex(last_idx)
                
                # Flag'i kaldır - artık onCategoryChanged çalışabilir
                self.in_go_back = False
                
                # Doğrudan CATEGORIES listesinden category ID al
                if last_idx < len(CATEGORIES):
                    cat_id = CATEGORIES[last_idx][0]
                    cat_name = CATEGORIES[last_idx][1]
                else:
                    cat_id = "all"
                    cat_name = "Tüm Eklentiler"
                
                # Status label'ı güncelle
                self["status_label"].setText(f"► {cat_name} - OK ile aç")
                
                # Plugin listesini bu kategori için yeniden oluştur
                self.current_category = cat_id
                self.applyFilters()
                
                # Plugin sayısını güncelle
                self["plugin_count"].setText(f"Toplam: {len(self.filtered_plugins)} Eklenti")
                
                # Plugin list style'ı güncelle (selection rengi transparent)
                self.updatePluginListStyle()
                
                # Mavi tuş etiketini ayarlara çevir
                self["key_blue"].setText("⚙ AYARLAR")
                
                self["status_label"].setText("► Kategori - OK:Aç EXIT:Çık")
            except Exception as e:
                logger.debug(f"goBack error: {str(e)}")
                self.in_go_back = False
        else:
            # Kategori panelinden çık
            self.close()
    
    def exitConfirm(self, answer):
        """Çıkış onayı"""
        if answer:
            self.close()
    
    def switchToCategory(self):
        self.active_panel = "categories"
        self["catlist"].moveToIndex(0)
        self["status_label"].setText("► Kategori - OK:Aç EXIT:Çık")
        self["key_blue"].setText("⚙ AYARLAR")  # Mavi tuş etiketini ayarlara çevir
        # Kategori bilgisini göster
        current = self["catlist"].getCurrent()
        if current and len(current) > 0:
            cat_name = current[0][1]
            self["info_title"].setText(cat_name)
    
    def switchToPlugins(self):
        self.active_panel = "plugins"
        self["pluginlist"].moveToIndex(0)
        self.refreshDescription()
        self["key_blue"].setText("📷 RESİMLER")  # Mavi tuş etiketini resimlere çevir
        self["status_label"].setText("► Plugin - OK:Kur/Kaldır 📷:Resimler EXIT:Geri")
    
    def exit(self):
        """Plugin'i kapat"""
        try:
            if self.time_timer:
                self.time_timer.stop()
        except:
            pass
        self.close()

def main(session, **kwargs):
    session.open(CanPanelList)
def menu(menuid, **kwargs):
	if menuid == "mainmenu":
		return [(_("Can Panel"), main, _("CanPanel_"), 48)]
	return []

def Plugins(**kwargs):
    from Plugins.Plugin import PluginDescriptor
    return [PluginDescriptor(
        name="Can Panel",
        description=f"Can Panel Uygulama Yoneticisi v{PLUGIN_VERSION}",
        where=PluginDescriptor.WHERE_PLUGINMENU,
        fnc=main,
        icon="plugin.png"
    ),
            PluginDescriptor(name="Can Panel", 
            description=_("Uygulama"), 
            where=PluginDescriptor.WHERE_MENU, fnc=menu)
            ]
